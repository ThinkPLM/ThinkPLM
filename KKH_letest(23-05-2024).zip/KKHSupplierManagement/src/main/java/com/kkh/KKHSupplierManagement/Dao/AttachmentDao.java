package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Attachment;

public interface AttachmentDao extends JpaRepository<Attachment,Long>{

	
	
}
