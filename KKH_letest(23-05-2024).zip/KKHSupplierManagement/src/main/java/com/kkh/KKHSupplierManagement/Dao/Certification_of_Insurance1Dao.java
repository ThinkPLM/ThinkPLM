package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance1;


public interface Certification_of_Insurance1Dao  extends JpaRepository<Certification_of_Insurance1,Long>{

	
}
