package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance;

public interface Certification_of_InsuranceDao  extends JpaRepository<Certification_of_Insurance,Long> {

}
