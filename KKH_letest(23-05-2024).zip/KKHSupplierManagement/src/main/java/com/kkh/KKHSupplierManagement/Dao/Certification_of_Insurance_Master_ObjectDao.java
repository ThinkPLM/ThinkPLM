package com.kkh.KKHSupplierManagement.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_MasterObject;


public interface Certification_of_Insurance_Master_ObjectDao extends JpaRepository<Certification_of_Insurance_Master_Object,Long> {

	
	 @Query("SELECT p FROM Certification_of_Insurance_Master_Object p WHERE p.document_number = ?1")
	 List<Certification_of_Insurance_Master_Object> findByDocument_number(String document_number);
	
	 
	 @Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM Certification_of_Insurance_Master_Object WHERE document_number = :documentNumber")
	    boolean existsByDocumentNumber(@Param("documentNumber") String documentNumber);

	    @Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM Certification_of_Insurance_Master_Object WHERE document_name = :documentName")
	    boolean existsByDocumentName(@Param("documentName") String documentName);
	    
	    
		@Query("SELECT i FROM Certification_of_Insurance_Master_Object i WHERE (LOWER(i.document_number) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
			       "OR LOWER(i.document_name) LIKE LOWER(CONCAT('%', :keyword, '%')))")
			List<Certification_of_Insurance_Master_Object> findByDocumentNumberOrDocumentName(@Param("keyword") String keyword);

}
