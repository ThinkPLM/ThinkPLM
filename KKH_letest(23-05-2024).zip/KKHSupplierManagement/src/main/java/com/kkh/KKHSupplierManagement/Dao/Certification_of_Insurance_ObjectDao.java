package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Object;


public interface Certification_of_Insurance_ObjectDao extends JpaRepository<Certification_of_Insurance_Object,Long>{

}
