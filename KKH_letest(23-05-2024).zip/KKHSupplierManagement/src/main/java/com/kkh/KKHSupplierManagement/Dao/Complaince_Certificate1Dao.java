package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate1;

public interface Complaince_Certificate1Dao extends JpaRepository<Complaince_Certificate1,Long>{

}
