package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_Master;

public interface Complaince_Certificate_MasterDao extends JpaRepository<Complaince_Certificate_Master,Long>{

}
