package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_Object;
public interface Complaince_Certificate_ObjectDao extends JpaRepository<Complaince_Certificate_Object,Long>{

}
