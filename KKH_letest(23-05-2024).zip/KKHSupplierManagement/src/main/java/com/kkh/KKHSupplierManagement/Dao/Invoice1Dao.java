package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Invoice1;

public interface Invoice1Dao extends JpaRepository<Invoice1,Long>{

}
