package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Invoice_Master;

public interface Invoice_MasterDao extends JpaRepository<Invoice_Master,Long>{

}
