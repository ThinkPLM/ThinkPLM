package com.kkh.KKHSupplierManagement.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;

public interface Invoice_Master_ObjectDao extends JpaRepository<Invoice_Master_Object, Long> {

	@Query("SELECT p FROM Invoice_Master_Object p WHERE p.invoice_number = ?1")
	List<Invoice_Master_Object> findByInvoice_number(String invoice_number);

	@Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM Invoice_Master_Object WHERE invoice_number = :invoiceNumber")
	boolean existsByInvoiceNumber(@Param("invoiceNumber") String invoiceNumber);

	@Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM Invoice_Master_Object WHERE invoice_name = :invoiceName")
	boolean existsByInvoiceName(@Param("invoiceName") String invoiceName);


//	@Query("SELECT i FROM Invoice_Master_Object i WHERE i.invoice_number = :keyword OR i.invoice_name = :keyword")
//	List<Invoice_Master_Object> findByInvoiceNumberOrInvoiceName(@Param("keyword") String keyword);

	
	@Query("SELECT i FROM Invoice_Master_Object i WHERE (LOWER(i.invoice_number) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
		       "OR LOWER(i.invoice_name) LIKE LOWER(CONCAT('%', :keyword, '%')))")
		List<Invoice_Master_Object> findByInvoiceNumberOrInvoiceName(@Param("keyword") String keyword);

}
