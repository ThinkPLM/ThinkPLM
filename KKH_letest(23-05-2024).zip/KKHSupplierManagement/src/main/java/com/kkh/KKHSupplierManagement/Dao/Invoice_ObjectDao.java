package com.kkh.KKHSupplierManagement.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Invoice_Object;

public interface Invoice_ObjectDao extends JpaRepository<Invoice_Object,Long>{

//	 @Query("SELECT io FROM Invoice_Object io WHERE io.master = :master AND io.islatest_Iteration = :islatest_Iteration")
//	    List<Invoice_Object> findByMasterAndIsLatest_Iteration(@Param("master") Invoice_Master_Object master, @Param("islatest_Iteration") int islatest_Iteration);
//	
//	 @Query("SELECT io FROM Invoice_Object io WHERE io.invoice_Object = :invoice_Object AND io.islatest_Iteration = :islatest_Iteration")
//	    List<Invoice_Object> findByInvoice_ObjectAndIsLatest_Iteration(@Param("invoice_Object") Invoice_Master_Object invoice_Object, @Param("islatest_Iteration") int islatest_Iteration);

	    @Query("SELECT io FROM Invoice_Object io WHERE io.invoice_Object = :invoice_Object AND io.islatest_Iteration = 1")
	    List<Invoice_Object> findLatestInvoiceObjectsByInvoice_Object(@Param("invoice_Object") Invoice_Master_Object invoice_Object);
}
