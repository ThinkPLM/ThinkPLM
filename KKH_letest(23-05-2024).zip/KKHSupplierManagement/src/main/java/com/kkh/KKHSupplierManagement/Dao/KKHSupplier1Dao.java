package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.KKHSupplier1;

public interface KKHSupplier1Dao extends JpaRepository<KKHSupplier1,Long>{

}
