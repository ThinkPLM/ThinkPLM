package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.KKHSupplier_Master;

public interface KKHSupplier_MasterDao extends JpaRepository<KKHSupplier_Master,Long> {

}
