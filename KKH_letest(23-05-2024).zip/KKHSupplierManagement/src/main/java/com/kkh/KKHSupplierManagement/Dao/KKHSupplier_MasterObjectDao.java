package com.kkh.KKHSupplierManagement.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master_Object;
import com.kkh.KKHSupplierManagement.resource.KKHSupplier;
import com.kkh.KKHSupplierManagement.resource.KKHSupplier_MasterObject;


public interface KKHSupplier_MasterObjectDao extends JpaRepository<KKHSupplier_MasterObject,Long>{

	
	 @Query("SELECT p FROM KKHSupplier_MasterObject p WHERE p.name = ?1")
	 List<KKHSupplier_MasterObject> findByName(String part_number);
	 
		public List<KKHSupplier_MasterObject> findByCategory(String category);
	 
	    @Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM KKHSupplier_MasterObject WHERE name = :Name")
	    boolean existsByName(@Param("Name") String Name);
	  
	    
	    @Query("SELECT i FROM KKHSupplier_MasterObject i WHERE LOWER(i.name) LIKE LOWER(CONCAT('%', :keyword, '%'))")
	    List<KKHSupplier_MasterObject> findByName1(@Param("keyword") String keyword);

	    
}