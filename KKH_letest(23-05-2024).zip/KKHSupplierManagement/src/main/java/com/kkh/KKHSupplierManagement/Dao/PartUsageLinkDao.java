package com.kkh.KKHSupplierManagement.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.kkh.KKHSupplierManagement.resource.PartUsageLink;
@Repository
public interface PartUsageLinkDao extends JpaRepository<PartUsageLink, Long> {

	@Query("SELECT usage FROM PartUsageLink usage WHERE usage.ida3a5 = ?1")
	 List<PartUsageLink> findByParentId(Long parentID);
	 
	
    void deleteByIda3a5AndIda3b5(@Param("ida3a5") Long ida3a5, @Param("ida3b5") Long ida3b5);

    
    @Query("SELECT CASE WHEN COUNT(p) > 0 THEN true ELSE false END FROM PartUsageLink p WHERE p.ida3b5 = :ida3b5")
    boolean existsByIda3b5(@Param("ida3b5") Long ida3b5);
    
    @Query("SELECT CASE WHEN COUNT(p) > 0 THEN true ELSE false END FROM PartUsageLink p WHERE p.ida3a5 = :ida3a5")
    boolean existsByIda3a5(@Param("ida3a5") Long ida3a5);
    
}
