package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Supplier_Contract1;


public interface Supplier_Contract1Dao extends JpaRepository<Supplier_Contract1,Long> {

}
