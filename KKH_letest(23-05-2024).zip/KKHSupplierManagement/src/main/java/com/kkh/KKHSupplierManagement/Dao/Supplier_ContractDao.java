package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Supplier_Contract;

//Supplier_Contract
public interface Supplier_ContractDao extends JpaRepository<Supplier_Contract,Long> {

}
