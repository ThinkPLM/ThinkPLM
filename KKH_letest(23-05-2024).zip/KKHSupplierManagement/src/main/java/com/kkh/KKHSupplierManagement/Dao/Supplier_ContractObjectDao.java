package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Supplier_ContractObject;


public interface Supplier_ContractObjectDao extends JpaRepository<Supplier_ContractObject,Long>{

}
