package com.kkh.KKHSupplierManagement.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;

public interface Supplier_MasterContractObjectDao  extends JpaRepository<Supplier_MasterContractObject,Long> {

	 @Query("SELECT p FROM Supplier_MasterContractObject p WHERE p.document_number = ?1")
	 List<Supplier_MasterContractObject> findByDocument_number(String document_number);
	 
//	 Optional<Supplier_MasterContractObject> getSupplierMasterContractObjectByIdWithContractsAndAttachments(Long masterId);
	
	 
	 @Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM Supplier_MasterContractObject WHERE document_number = :documentNumber")
	    boolean existsByDocumentNumber(@Param("documentNumber") String documentNumber);

	    @Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM Supplier_MasterContractObject WHERE document_name = :documentName")
	    boolean existsByDocumentName(@Param("documentName") String documentName);
	    
		@Query("SELECT i FROM Supplier_MasterContractObject i WHERE (LOWER(i.document_number) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
			       "OR LOWER(i.document_name) LIKE LOWER(CONCAT('%', :keyword, '%')))")
			List<Supplier_MasterContractObject> findByDocumentNumberOrDocumentName(@Param("keyword") String keyword);

}
