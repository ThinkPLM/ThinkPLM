package com.kkh.KKHSupplierManagement.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;


public interface Supplier_MasterPartObjectDao extends JpaRepository<Supplier_MasterPartObject,Long>  {

	 @Query("SELECT p FROM Supplier_MasterPartObject p WHERE p.part_number = ?1")
	 List<Supplier_MasterPartObject> findByPart_number(String part_number);
	
	 @Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM Supplier_MasterPartObject WHERE part_number = :partNumber")
	    boolean existsByPartNumber(@Param("partNumber") String partNumber);

	    @Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM Supplier_MasterPartObject WHERE part_name = :partName")
	    boolean existsByPartName(@Param("partName") String partName);
	    
//	    List<Supplier_MasterPartObject> findBypartNumberContainingIgnoreCaseOrpartNameContainingIgnoreCase(String part_number, String part_name);
	  
//	    @Query("SELECT p FROM Supplier_MasterPartObject p WHERE LOWER(p.part_number) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(p.part_name) LIKE LOWER(CONCAT('%', :keyword, '%'))")
//	    List<Supplier_MasterPartObject> searchByPartNumberOrPartName(@Param("keyword") String keyword);

	    
	    @Query("SELECT DISTINCT p FROM Supplier_MasterPartObject p " +
	            "LEFT JOIN FETCH p.parts io " +
	            "WHERE (LOWER(p.part_number) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
	            "OR LOWER(p.part_name) LIKE LOWER(CONCAT('%', :keyword, '%'))) " +
	            "AND io.islatest_Iteration = 1")
	     List<Supplier_MasterPartObject> searchByPartNumberOrPartNameWithLatestParts(@Param("keyword") String keyword);

}
