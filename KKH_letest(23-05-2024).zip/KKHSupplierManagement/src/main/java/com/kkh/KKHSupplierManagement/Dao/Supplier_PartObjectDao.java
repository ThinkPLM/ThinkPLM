package com.kkh.KKHSupplierManagement.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_PartObject;



public interface Supplier_PartObjectDao extends JpaRepository<Supplier_PartObject,Long>  {

	  List<Supplier_PartObject> findByMasterId(Long masterId);
	  
	  @Query("SELECT sp FROM Supplier_PartObject sp WHERE sp.masterPartObject = :masterPartObject AND sp.islatest_Iteration = :islatest_Iteration")
	    List<Supplier_PartObject> findByMasterPartObjectAndIsLatest_Iteration(@Param("masterPartObject") Supplier_MasterPartObject masterPartObject, @Param("islatest_Iteration") int islatest_Iteration);
}
