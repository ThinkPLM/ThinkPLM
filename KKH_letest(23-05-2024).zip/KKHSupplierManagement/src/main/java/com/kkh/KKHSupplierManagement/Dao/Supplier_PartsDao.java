package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Supplier_Parts;



public interface Supplier_PartsDao extends JpaRepository<Supplier_Parts,Long>  {

	
}
