package com.kkh.KKHSupplierManagement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kkh.KKHSupplierManagement.resource.Supplier_Purchase_Order;



public interface Supplier_Purchase_OrderDao extends JpaRepository<Supplier_Purchase_Order,Long>{

	
	
	
	
}
