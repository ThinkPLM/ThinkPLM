package com.kkh.KKHSupplierManagement.resource;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
@Entity
public class Attachment {

	@Id
	@GeneratedValue()

	private Long id;

    private String fileName;

	private String fileType;


	@Column(columnDefinition = "LONGBLOB")
	private String content;
	
	private String attachmentType;

	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	
	public String getAttachmentType() {
		return attachmentType;
	}
	public void setAttachmentType(String attachmenType) {
		this.attachmentType = attachmenType;
	}
	
	
	
	public Attachment(Long id, String fileName, String fileType, String content, String attachmentType) {
		super();
		this.id = id;
		this.fileName = fileName;
		this.fileType = fileType;
		this.content = content;
		this.attachmentType = attachmentType;
	}
	
	
	@Override
	public String toString() {
		return "Attachment [id=" + id + ", fileName=" + fileName + ", fileType=" + fileType + ", content=" + content
				+ ", attachmenType=" + attachmentType + "]";
	}
	public Attachment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
