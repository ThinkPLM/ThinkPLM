package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Certification_of_Insurance1 {

	@Id
	@GeneratedValue
	private Long id;
	private Long policy_number;
	private String supplier_name;
	private String insured_party;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date effective_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date expiration_date;
	private String insurance_company;
	private Long masterId;
	private int iteration_info;
	private int islatest_Iteration;
	@ManyToOne
    @JoinColumn(name = "certification_of_Insurance_Master_Object")
	private Certification_of_Insurance_Master_Object certification_of_Insurance_Master_Object;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPolicy_number() {
		return policy_number;
	}

	public void setPolicy_number(Long policy_number) {
		this.policy_number = policy_number;
	}

	public String getSupplier_name() {
		return supplier_name;
	}

	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}

	public String getInsured_party() {
		return insured_party;
	}

	public void setInsured_party(String insured_party) {
		this.insured_party = insured_party;
	}

	public Date getEffective_date() {
		return effective_date;
	}

	public void setEffective_date(Date effective_date) {
		this.effective_date = effective_date;
	}

	public Date getExpiration_date() {
		return expiration_date;
	}

	public void setExpiration_date(Date expiration_date) {
		this.expiration_date = expiration_date;
	}

	public String getInsurance_company() {
		return insurance_company;
	}

	public void setInsurance_company(String insurance_company) {
		this.insurance_company = insurance_company;
	}

	public Long getMasterId() {
		return masterId;
	}

	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}

	public int getIteration_info() {
		return iteration_info;
	}

	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}

	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}

	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}
	public Certification_of_Insurance_Master_Object getCertification_of_Insurance_Master_Object() {
		return certification_of_Insurance_Master_Object;
	}

	public void setCertification_of_Insurance_Master_Object(
			Certification_of_Insurance_Master_Object certification_of_Insurance_Master_Object) {
		this.certification_of_Insurance_Master_Object = certification_of_Insurance_Master_Object;
	}


	

	public Certification_of_Insurance1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Certification_of_Insurance1(Long id, Long policy_number, String supplier_name, String insured_party,
			Date effective_date, Date expiration_date, String insurance_company, Long masterId, int iteration_info,
			int islatest_Iteration, Certification_of_Insurance_Master_Object certification_of_Insurance_Master_Object) {
		super();
		this.id = id;
		this.policy_number = policy_number;
		this.supplier_name = supplier_name;
		this.insured_party = insured_party;
		this.effective_date = effective_date;
		this.expiration_date = expiration_date;
		this.insurance_company = insurance_company;
		this.masterId = masterId;
		this.iteration_info = iteration_info;
		this.islatest_Iteration = islatest_Iteration;
		this.certification_of_Insurance_Master_Object = certification_of_Insurance_Master_Object;
	}

	@Override
	public String toString() {
		return "Certification_of_Insurance1 [id=" + id + ", policy_number=" + policy_number + ", supplier_name="
				+ supplier_name + ", insured_party=" + insured_party + ", effective_date=" + effective_date
				+ ", expiration_date=" + expiration_date + ", insurance_company=" + insurance_company + ", masterId="
				+ masterId + ", iteration_info=" + iteration_info + ", islatest_Iteration=" + islatest_Iteration
				+ ", certification_of_Insurance_Master_Object=" + certification_of_Insurance_Master_Object + "]";
	}


}
