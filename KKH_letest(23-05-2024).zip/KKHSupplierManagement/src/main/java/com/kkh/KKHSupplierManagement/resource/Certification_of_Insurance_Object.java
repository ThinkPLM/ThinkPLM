package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Certification_of_Insurance_Object {

	
	@Id
	@GeneratedValue
	private Long id;
	private String policy_number;
	private String supplier_name;
	private String attachmentId;
	private String insured_party;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate effective_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate expiration_date;
	private String insurance_company;
	private Long masterId;
	private int iteration_info;
	private int islatest_Iteration;

	@OneToMany(mappedBy = "id")
    @Fetch(value = FetchMode.SELECT)
	private Set<Attachment> attachment = new HashSet<>();
	
	@ManyToOne
    @JoinColumn(name = "certification_of_Insurance_Master_Object")
	private Certification_of_Insurance_Master_Object certification_of_Insurance_Master_Object;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPolicy_number() {
		return policy_number;
	}

	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}

	public String getSupplier_name() {
		return supplier_name;
	}

	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}

	public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	public String getInsured_party() {
		return insured_party;
	}

	public void setInsured_party(String insured_party) {
		this.insured_party = insured_party;
	}

	public LocalDate getEffective_date() {
		return effective_date;
	}

	public void setEffective_date(LocalDate effective_date) {
		this.effective_date = effective_date;
	}

	public LocalDate getExpiration_date() {
		return expiration_date;
	}

	public void setExpiration_date(LocalDate expiration_date) {
		this.expiration_date = expiration_date;
	}

	public String getInsurance_company() {
		return insurance_company;
	}

	public void setInsurance_company(String insurance_company) {
		this.insurance_company = insurance_company;
	}

	public Long getMasterId() {
		return masterId;
	}

	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}

	public int getIteration_info() {
		return iteration_info;
	}

	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}

	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}

	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}

	public Set<Attachment> getAttachment() {
		return attachment;
	}

	public void setAttachment(Set<Attachment> attachment) {
		this.attachment = attachment;
	}

	public Certification_of_Insurance_Object(Long id, String policy_number, String supplier_name, String attachmentId,
			String insured_party, LocalDate effective_date, LocalDate expiration_date, String insurance_company,
			Long masterId, int iteration_info, int islatest_Iteration, Set<Attachment> attachment,
			Certification_of_Insurance_Master_Object certification_of_Insurance_Master_Object) {
		super();
		this.id = id;
		this.policy_number = policy_number;
		this.supplier_name = supplier_name;
		this.attachmentId = attachmentId;
		this.insured_party = insured_party;
		this.effective_date = effective_date;
		this.expiration_date = expiration_date;
		this.insurance_company = insurance_company;
		this.masterId = masterId;
		this.iteration_info = iteration_info;
		this.islatest_Iteration = islatest_Iteration;
		this.attachment = attachment;
		this.certification_of_Insurance_Master_Object = certification_of_Insurance_Master_Object;
	}

	public Certification_of_Insurance_Object() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Certification_of_Insurance_Object [id=" + id + ", policy_number=" + policy_number + ", supplier_name="
				+ supplier_name + ", attachmentId=" + attachmentId + ", insured_party=" + insured_party
				+ ", effective_date=" + effective_date + ", expiration_date=" + expiration_date + ", insurance_company="
				+ insurance_company + ", masterId=" + masterId + ", iteration_info=" + iteration_info
				+ ", islatest_Iteration=" + islatest_Iteration + ", attachment=" + attachment
				+ ", certification_of_Insurance_Master_Object=" + certification_of_Insurance_Master_Object + "]";
	}
	
	
	
	
}
