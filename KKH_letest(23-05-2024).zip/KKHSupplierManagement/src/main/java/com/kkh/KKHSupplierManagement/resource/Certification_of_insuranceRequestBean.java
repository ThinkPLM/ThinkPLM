package com.kkh.KKHSupplierManagement.resource;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class Certification_of_insuranceRequestBean {

	
	@Id
	@GeneratedValue
	Long id;
	Certification_of_Insurance_Master certification_of_Insurance_Master;
	Certification_of_Insurance1 certification_of_Insurance1;
	
	
	public Certification_of_insuranceRequestBean(Long id,
			Certification_of_Insurance_Master savedcertification_of_Insurance_Master,
			Certification_of_Insurance1 savecertification_of_Insurance1) {
		
		this.id = id;
		this.certification_of_Insurance_Master = savedcertification_of_Insurance_Master;
		this.certification_of_Insurance1 = savecertification_of_Insurance1;
	}
	
	
	public Certification_of_insuranceRequestBean(Certification_of_insuranceRequestBean bean) {
		// TODO Auto-generated constructor stub
		this.id=bean.getId();
		this.certification_of_Insurance_Master = bean.getCertification_of_Insurance_Master();
		this.certification_of_Insurance1 = bean.getCertification_of_Insurance1();
				
	}
	
	


	public Certification_of_insuranceRequestBean() {
		
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Certification_of_Insurance_Master getCertification_of_Insurance_Master() {
		return certification_of_Insurance_Master;
	}


	public void setCertification_of_Insurance_Master(Certification_of_Insurance_Master certification_of_Insurance_Master) {
		this.certification_of_Insurance_Master = certification_of_Insurance_Master;
	}


	public Certification_of_Insurance1 getCertification_of_Insurance1() {
		return certification_of_Insurance1;
	}


	public void setCertification_of_Insurance1(Certification_of_Insurance1 certification_of_Insurance1) {
		this.certification_of_Insurance1 = certification_of_Insurance1;
	}
	
	
	
	
}
