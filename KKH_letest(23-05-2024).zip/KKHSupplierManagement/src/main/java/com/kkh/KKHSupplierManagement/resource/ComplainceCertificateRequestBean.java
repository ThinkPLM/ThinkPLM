package com.kkh.KKHSupplierManagement.resource;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class ComplainceCertificateRequestBean {
	@Id
	@GeneratedValue
	Long id;
	Complaince_Certificate_Master complaince_Certificate_Master;
	Complaince_Certificate1 complaince_Certificate1;
	public ComplainceCertificateRequestBean(Long id, Complaince_Certificate_Master savedcomplaince_Certificate_Master,Complaince_Certificate1 savecomplaince_Certificate1) {
	
		this.id= id;
		this.complaince_Certificate_Master = savedcomplaince_Certificate_Master;
		this.complaince_Certificate1 = savecomplaince_Certificate1;
		
	}
	
	public ComplainceCertificateRequestBean(ComplainceCertificateRequestBean bean) {
		this.id=bean.id;
		this.complaince_Certificate_Master=bean.getComplaince_Certificate_Master();
		this.complaince_Certificate1=bean.getComplaince_Certificate1();
		
	}

	public ComplainceCertificateRequestBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Complaince_Certificate_Master getComplaince_Certificate_Master() {
		return complaince_Certificate_Master;
	}

	public void setComplaince_Certificate_Master(Complaince_Certificate_Master complaince_Certificate_Master) {
		this.complaince_Certificate_Master = complaince_Certificate_Master;
	}

	public Complaince_Certificate1 getComplaince_Certificate1() {
		return complaince_Certificate1;
	}

	public void setComplaince_Certificate1(Complaince_Certificate1 complaince_Certificate1) {
		this.complaince_Certificate1 = complaince_Certificate1;
	}
	
	
}
