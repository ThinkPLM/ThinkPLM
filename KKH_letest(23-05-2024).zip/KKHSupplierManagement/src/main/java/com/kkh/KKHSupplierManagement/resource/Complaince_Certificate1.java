package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
@Entity
public class Complaince_Certificate1 {
	@Id
	@GeneratedValue
	private Long id;
	private String supplier_name;

	private String supplier_category;
	private String certification_number;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date certification_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date expiration_date;
	private Long masterId;
	private int iteration_info;
	private int islatest_Iteration;
	@ManyToOne
	@JoinColumn(name = "complaince_Certificate_MasterObject")
	private Complaince_Certificate_MasterObject complaince_Certificate_MasterObject;

	
	

	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getSupplier_name() {
		return supplier_name;
	}


	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}


	public String getSupplier_category() {
		return supplier_category;
	}


	public void setSupplier_category(String supplier_category) {
		this.supplier_category = supplier_category;
	}


	public String getCertification_number() {
		return certification_number;
	}


	public void setCertification_number(String certification_number) {
		this.certification_number = certification_number;
	}


	public Date getCertification_date() {
		return certification_date;
	}


	public void setCertification_date(Date certification_date) {
		this.certification_date = certification_date;
	}


	public Date getExpiration_date() {
		return expiration_date;
	}


	public void setExpiration_date(Date expiration_date) {
		this.expiration_date = expiration_date;
	}


	

	public Long getMasterId() {
		return masterId;
	}


	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}


	public int getIteration_info() {
		return iteration_info;
	}


	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}


	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}


	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}


	public Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObject() {
		return complaince_Certificate_MasterObject;
	}


	public void setComplaince_Certificate_MasterObject(
			Complaince_Certificate_MasterObject complaince_Certificate_MasterObject) {
		this.complaince_Certificate_MasterObject = complaince_Certificate_MasterObject;
	}


	public Complaince_Certificate1() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "Complaince_Certificate1 [id=" + id + ", supplier_name=" + supplier_name + ", supplier_category="
				+ supplier_category + ", certification_number=" + certification_number + ", certification_date="
				+ certification_date + ", expiration_date=" + expiration_date + ", masterId=" + masterId
				+ ", iteration_info=" + iteration_info + ", islatest_Iteration=" + islatest_Iteration
				+ ", complaince_Certificate_MasterObject=" + complaince_Certificate_MasterObject + "]";
	}


	public Complaince_Certificate1(Long id, String supplier_name, String supplier_category, String certification_number,
			Date certification_date, Date expiration_date, Long masterId, int iteration_info, int islatest_Iteration,
			Complaince_Certificate_MasterObject complaince_Certificate_MasterObject) {
		super();
		this.id = id;
		this.supplier_name = supplier_name;
		this.supplier_category = supplier_category;
		this.certification_number = certification_number;
		this.certification_date = certification_date;
		this.expiration_date = expiration_date;
		this.masterId = masterId;
		this.iteration_info = iteration_info;
		this.islatest_Iteration = islatest_Iteration;
		this.complaince_Certificate_MasterObject = complaince_Certificate_MasterObject;
	}
	
	

}
