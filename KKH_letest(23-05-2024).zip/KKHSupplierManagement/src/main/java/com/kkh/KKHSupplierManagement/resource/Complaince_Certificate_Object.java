package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
@Entity
public class Complaince_Certificate_Object {
	@Id
	@GeneratedValue
	private Long id;
	private String supplier_name;
	private String attachmentId;

	private String supplier_category;
	private String certification_number;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate certification_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate expiration_date;
	private Long masterId;
	private int iteration_info;
	private int islatest_Iteration;
	@ManyToOne
	@JoinColumn(name = "complaince_Certificate_MasterObject")
	private Complaince_Certificate_MasterObject complaince_Certificate_MasterObject;

	@OneToMany(mappedBy = "id")
    @Fetch(value = FetchMode.SELECT)
	private Set<Attachment> attachment = new HashSet<>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSupplier_name() {
		return supplier_name;
	}

	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}

	public String getSupplier_category() {
		return supplier_category;
	}

	public void setSupplier_category(String supplier_category) {
		this.supplier_category = supplier_category;
	}

	public String getCertification_number() {
		return certification_number;
	}

	public void setCertification_number(String certification_number) {
		this.certification_number = certification_number;
	}

		public Long getMasterId() {
		return masterId;
	}

	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}

	public int getIteration_info() {
		return iteration_info;
	}

	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}

	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}

	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}

	
	

	public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	public Set<Attachment> getAttachment() {
		return attachment;
	}

	public void setAttachment(Set<Attachment> attachment) {
		this.attachment = attachment;
	}

	
	
	

	public LocalDate getCertification_date() {
		return certification_date;
	}

	public void setCertification_date(LocalDate certification_date) {
		this.certification_date = certification_date;
	}

	public LocalDate getExpiration_date() {
		return expiration_date;
	}

	public void setExpiration_date(LocalDate expiration_date) {
		this.expiration_date = expiration_date;
	}

	public Complaince_Certificate_Object(Long id, String supplier_name, String attachmentId, String supplier_category,
			String certification_number, LocalDate certification_date, LocalDate expiration_date, Long masterId,
			int iteration_info, int islatest_Iteration,
			Complaince_Certificate_MasterObject complaince_Certificate_MasterObject, Set<Attachment> attachment) {
		super();
		this.id = id;
		this.supplier_name = supplier_name;
		this.attachmentId = attachmentId;
		this.supplier_category = supplier_category;
		this.certification_number = certification_number;
		this.certification_date = certification_date;
		this.expiration_date = expiration_date;
		this.masterId = masterId;
		this.iteration_info = iteration_info;
		this.islatest_Iteration = islatest_Iteration;
		this.complaince_Certificate_MasterObject = complaince_Certificate_MasterObject;
		this.attachment = attachment;
	}

	public Complaince_Certificate_Object() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Complaince_Certificate_Object [id=" + id + ", supplier_name=" + supplier_name + ", attachmentId="
				+ attachmentId + ", supplier_category=" + supplier_category + ", certification_number="
				+ certification_number + ", certification_date=" + certification_date + ", expiration_date="
				+ expiration_date + ", masterId=" + masterId + ", iteration_info=" + iteration_info
				+ ", islatest_Iteration=" + islatest_Iteration + ", complaince_Certificate_MasterObject="
				+ complaince_Certificate_MasterObject + ", attachment=" + attachment + "]";
	}

	
}
