package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Invoice1 {

	@Id
	@GeneratedValue
	private Long id;
	private String invoice_name;

	private String supplier_name;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date invoice_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date due_date;
	private String amount_due;
	private Long masterId;
	private int iteration_info;
	private int islatest_Iteration;
	@ManyToOne
	@JoinColumn(name = "invoice_Object")
	private Invoice_Master_Object invoice_Object;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInvoice_name() {
		return invoice_name;
	}

	public void setInvoice_name(String invoice_name) {
		this.invoice_name = invoice_name;
	}

	public String getSupplier_name() {
		return supplier_name;
	}

	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}

	public Date getInvoice_date() {
		return invoice_date;
	}

	public void setInvoice_date(Date invoice_date) {
		this.invoice_date = invoice_date;
	}

	public Date getDue_date() {
		return due_date;
	}

	public void setDue_date(Date due_date) {
		this.due_date = due_date;
	}

	public String getAmount_due() {
		return amount_due;
	}

	public void setAmount_due(String amount_due) {
		this.amount_due = amount_due;
	}

	public Long getMasterId() {
		return masterId;
	}

	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}

	public int getIteration_info() {
		return iteration_info;
	}

	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}

	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}

	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}

	public Invoice_Master_Object getInvoice_Object() {
		return invoice_Object;
	}

	public void setInvoice_Object(Invoice_Master_Object invoice_Object) {
		this.invoice_Object = invoice_Object;
	}


	
	public Invoice1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Invoice1(Long id, String invoice_name, String supplier_name, Date invoice_date, Date due_date,
			String amount_due, Long masterId, int iteration_info, int islatest_Iteration,
			Invoice_Master_Object invoice_Object) {
		super();
		this.id = id;
		this.invoice_name = invoice_name;
		this.supplier_name = supplier_name;
		this.invoice_date = invoice_date;
		this.due_date = due_date;
		this.amount_due = amount_due;
		this.masterId = masterId;
		this.iteration_info = iteration_info;
		this.islatest_Iteration = islatest_Iteration;
		this.invoice_Object = invoice_Object;
	}

	@Override
	public String toString() {
		return "Invoice1 [id=" + id + ", invoice_name=" + invoice_name + ", supplier_name=" + supplier_name
				+ ", invoice_date=" + invoice_date + ", due_date=" + due_date + ", amount_due=" + amount_due
				+ ", masterId=" + masterId + ", iteration_info=" + iteration_info + ", islatest_Iteration="
				+ islatest_Iteration + ", invoice_Object=" + invoice_Object + "]";
	}

	
}
