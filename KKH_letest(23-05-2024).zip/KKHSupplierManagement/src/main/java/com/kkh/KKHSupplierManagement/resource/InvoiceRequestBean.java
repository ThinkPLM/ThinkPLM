package com.kkh.KKHSupplierManagement.resource;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class InvoiceRequestBean {
	@Id
	@GeneratedValue
	Long id;
	Invoice_Master invoice_Master;
	Invoice1 invoice1;
	public InvoiceRequestBean(Long id, Invoice_Master invoice_Master, Invoice1 invoice1) {
		super();
		this.id = id;
		this.invoice_Master = invoice_Master;
		this.invoice1 = invoice1;
	}
	
	
	
	public InvoiceRequestBean(InvoiceRequestBean bean) {
		this.id=bean.getId();
		this.invoice_Master=bean.getInvoice_Master();
		this.invoice1=bean.getInvoice1();
	}
	
	
	
	
	public InvoiceRequestBean() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Invoice_Master getInvoice_Master() {
		return invoice_Master;
	}
	public void setInvoice_Master(Invoice_Master invoice_Master) {
		this.invoice_Master = invoice_Master;
	}
	public Invoice1 getInvoice1() {
		return invoice1;
	}
	public void setInvoice1(Invoice1 invoice1) {
		this.invoice1 = invoice1;
	}
	
	
}
