package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
@Entity
public class Invoice_Object {

	
	@Id
	@GeneratedValue
	private Long id;
	private String invoice_name; 
	private String attachmentId;
	private String supplier_name;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate invoice_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate due_date;
	private String amount_due;
	private Long masterId;
	private int iteration_info;
	private int islatest_Iteration;
	@OneToMany(mappedBy = "id")
    @Fetch(value = FetchMode.SELECT)
	private Set<Attachment> attachment = new HashSet<>();

	@ManyToOne
	@JoinColumn(name = "invoice_Object")
	private Invoice_Master_Object invoice_Object;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getInvoice_name() {
		return invoice_name;
	}
	public void setInvoice_name(String invoice_name) {
		this.invoice_name = invoice_name;
	}
	public String getSupplier_name() {
		return supplier_name;
	}
	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}

	public String getAmount_due() {
		return amount_due;
	}
	public void setAmount_due(String amount_due) {
		this.amount_due = amount_due;
	}
	public Long getMasterId() {
		return masterId;
	}
	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}
	public int getIteration_info() {
		return iteration_info;
	}
	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}
	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}
	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}
	
	
	
	public String getAttachmentId() {
		return attachmentId;
	}
	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}
	public Set<Attachment> getAttachment() {
		return attachment;
	}
	public void setAttachment(Set<Attachment> attachment) {
		this.attachment = attachment;
	}
	
	
	
	public LocalDate getInvoice_date() {
		return invoice_date;
	}
	public void setInvoice_date(LocalDate invoice_date) {
		this.invoice_date = invoice_date;
	}
	public LocalDate getDue_date() {
		return due_date;
	}
	public void setDue_date(LocalDate due_date) {
		this.due_date = due_date;
	}
	
	public Invoice_Object() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Invoice_Object(Long id, String invoice_name, String attachmentId, String supplier_name,
			LocalDate invoice_date, LocalDate due_date, String amount_due, Long masterId, int iteration_info,
			int islatest_Iteration, Set<Attachment> attachment, Invoice_Master_Object invoice_Object) {
		super();
		this.id = id;
		this.invoice_name = invoice_name;
		this.attachmentId = attachmentId;
		this.supplier_name = supplier_name;
		this.invoice_date = invoice_date;
		this.due_date = due_date;
		this.amount_due = amount_due;
		this.masterId = masterId;
		this.iteration_info = iteration_info;
		this.islatest_Iteration = islatest_Iteration;
		this.attachment = attachment;
		this.invoice_Object = invoice_Object;
	}
	@Override
	public String toString() {
		return "Invoice_Object [id=" + id + ", invoice_name=" + invoice_name + ", attachmentId=" + attachmentId
				+ ", supplier_name=" + supplier_name + ", invoice_date=" + invoice_date + ", due_date=" + due_date
				+ ", amount_due=" + amount_due + ", masterId=" + masterId + ", iteration_info=" + iteration_info
				+ ", islatest_Iteration=" + islatest_Iteration + ", attachment=" + attachment + ", invoice_Object="
				+ invoice_Object + "]";
	}
	
	
	
	
	
}
