package com.kkh.KKHSupplierManagement.resource;

import java.util.ArrayList;
import java.util.List;

public class KKHPartBomDetails {

	private KKHPartData data;
	private List<Integer> replies = new ArrayList<Integer>();
	
	public KKHPartData getData() {
		return data;
	}
	public void setData(KKHPartData data) {
		this.data = data;
	}
	public List<Integer> getReplies() {
		return replies;
	}
	public void setReplies(List<Integer> replies) {
		this.replies = replies;
	}

}
