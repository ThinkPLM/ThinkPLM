package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;

public class KKHPartData {

	private Long id;
	private Long parentId;
	private List<Long> childId = new ArrayList<>();
	private String part_number;
	private String part_name;
	private String description;
	private LocalDate createdDate;
	private String supplier_category;
	private String supplier_name;
	private String material;
	private String mpn_number;
	private String weight;
	private String dimension;
	private String cost;
	private LocalDate lead_date;
	private String quality_matrices;
	private String compliance_information;
	private LocalDate modifiedDate;
	private  int iteration_info;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public List<Long> getChildId() {
		return childId;
	}
	public void setChildId(List<Long> childId) {
		this.childId = childId;
	}
	public String getPart_number() {
		return part_number;
	}
	public void setPart_number(String part_number) {
		this.part_number = part_number;
	}
	public String getPart_name() {
		return part_name;
	}
	public void setPart_name(String part_name) {
		this.part_name = part_name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getSupplier_category() {
		return supplier_category;
	}
	public void setSupplier_category(String supplier_category) {
		this.supplier_category = supplier_category;
	}
	public String getSupplier_name() {
		return supplier_name;
	}
	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getMpn_number() {
		return mpn_number;
	}
	public void setMpn_number(String mpn_number) {
		this.mpn_number = mpn_number;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getQuality_matrices() {
		return quality_matrices;
	}
	public void setQuality_matrices(String quality_matrices) {
		this.quality_matrices = quality_matrices;
	}
	public String getCompliance_information() {
		return compliance_information;
	}
	public void setCompliance_information(String compliance_information) {
		this.compliance_information = compliance_information;
	}
	
	public int getIteration_info() {
		return iteration_info;
	}
	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}
	public LocalDate getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}
	public LocalDate getLead_date() {
		return lead_date;
	}
	public void setLead_date(LocalDate lead_date) {
		this.lead_date = lead_date;
	}
	public LocalDate getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(LocalDate modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	

}
