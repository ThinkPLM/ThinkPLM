package com.kkh.KKHSupplierManagement.resource;

import java.util.ArrayList;
import java.util.List;

public class KKHPartStructureResponse {

	private Long topLevelParentId;
    private List<KKHPartBomDetails> partBomDetailsList = new ArrayList<KKHPartBomDetails>();
	
	public Long getTopLevelParentId() {
		return topLevelParentId;
	}
	public void setTopLevelParentId(Long topLevelParentId) {
		this.topLevelParentId = topLevelParentId;
	}
	public List<KKHPartBomDetails> getPartBomDetailsList() {
		return partBomDetailsList;
	}
	public void setPartBomDetailsList(List<KKHPartBomDetails> partBomDetailsList) {
		this.partBomDetailsList = partBomDetailsList;
	}
	
}
