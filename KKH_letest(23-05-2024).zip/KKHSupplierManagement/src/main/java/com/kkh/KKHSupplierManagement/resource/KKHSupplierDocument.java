package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.*;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer"})
public class KKHSupplierDocument {

	@Id
	@GeneratedValue()

	private Long id;

	private String fileName;

	private String fileType;

	@Column(columnDefinition = "LONGBLOB")
	// @Lob
	private String document;


	public KKHSupplierDocument() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}



	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}


	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public KKHSupplierDocument(Long id, String fileName, String fileType, String document) {
		super();
		this.id = id;
		this.fileName = fileName;
		this.fileType = fileType;
		this.document = document;
	}



}
