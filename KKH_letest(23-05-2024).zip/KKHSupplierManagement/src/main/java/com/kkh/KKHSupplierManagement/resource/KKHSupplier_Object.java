package com.kkh.KKHSupplierManagement.resource;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
@Entity
public class KKHSupplier_Object {

	@Id
	@GeneratedValue
	private Long id;
	private String email;
	private Long contact;
	private String pt;
	private String country;
	private String state;
	private String district;
	private String location;
	  private String documentId;
	private Long masterId;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate start_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate end_date;
	private int iteration_info;
	private int islatest_Iteration;
	
	   @OneToMany(mappedBy = "id")
	    @Fetch(value = FetchMode.SELECT)
		private Set<KKHSupplierDocument> document = new HashSet<>();
	@ManyToOne
	@JoinColumn(name = "supplierObject")
	private KKHSupplier_MasterObject supplierObject;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getContact() {
		return contact;
	}
	public void setContact(Long contact) {
		this.contact = contact;
	}
	public String getPt() {
		return pt;
	}
	public void setPt(String pt) {
		this.pt = pt;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

	public Long getMasterId() {
		return masterId;
	}
	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}
	
	public int getIteration_info() {
		return iteration_info;
	}
	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}
	
	
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	
	public Set<KKHSupplierDocument> getDocument() {
		return document;
	}
	public void setDocument(Set<KKHSupplierDocument> document) {
		this.document = document;
	}
	
	public LocalDate getStart_date() {
		return start_date;
	}
	public void setStart_date(LocalDate start_date) {
		this.start_date = start_date;
	}
	public LocalDate getEnd_date() {
		return end_date;
	}
	public void setEnd_date(LocalDate end_date) {
		this.end_date = end_date;
	}
	
	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}
	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}
	public KKHSupplier_Object() {
		super();
		// TODO Auto-generated constructor stub
	}
	public KKHSupplier_Object(Long id, String email, Long contact, String pt, String country, String state,
			String district, String location, String documentId, Long masterId, LocalDate start_date,
			LocalDate end_date, int iteration_info, int islatest_Iteration, Set<KKHSupplierDocument> document,
			KKHSupplier_MasterObject supplierObject) {
		super();
		this.id = id;
		this.email = email;
		this.contact = contact;
		this.pt = pt;
		this.country = country;
		this.state = state;
		this.district = district;
		this.location = location;
		this.documentId = documentId;
		this.masterId = masterId;
		this.start_date = start_date;
		this.end_date = end_date;
		this.iteration_info = iteration_info;
		this.islatest_Iteration = islatest_Iteration;
		this.document = document;
		this.supplierObject = supplierObject;
	}
	@Override
	public String toString() {
		return "KKHSupplier_Object [id=" + id + ", email=" + email + ", contact=" + contact + ", pt=" + pt
				+ ", country=" + country + ", state=" + state + ", district=" + district + ", location=" + location
				+ ", documentId=" + documentId + ", masterId=" + masterId + ", start_date=" + start_date + ", end_date="
				+ end_date + ", iteration_info=" + iteration_info + ", islatest_Iteration=" + islatest_Iteration
				+ ", document=" + document + ", supplierObject=" + supplierObject + "]";
	}

	

}
