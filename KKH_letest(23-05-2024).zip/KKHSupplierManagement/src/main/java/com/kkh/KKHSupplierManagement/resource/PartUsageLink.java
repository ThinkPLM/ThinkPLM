package com.kkh.KKHSupplierManagement.resource;


import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class PartUsageLink {

	@Id
	@GeneratedValue()
	private Long id;

	private Long ida3a5;

	private Long ida3b5;

	private String quantity;
	
	private String 	unit;
	private String traceCode;
	private String lineNumber;
	private String findNumber;
	private String referenceDesignator;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIda3a5() {
		return ida3a5;
	}

	public void setIda3a5(Long ida3a5) {
		this.ida3a5 = ida3a5;
	}

	public Long getIda3b5() {
		return ida3b5;
	}

	public void setIda3b5(Long ida3b5) {
		this.ida3b5 = ida3b5;
	}
	

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getTraceCode() {
		return traceCode;
	}

	public void setTraceCode(String traceCode) {
		this.traceCode = traceCode;
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getFindNumber() {
		return findNumber;
	}

	public void setFindNumber(String findNumber) {
		this.findNumber = findNumber;
	}

	public String getReferenceDesignator() {
		return referenceDesignator;
	}

	public void setReferenceDesignator(String referenceDesignator) {
		this.referenceDesignator = referenceDesignator;
	}

	public PartUsageLink(Long id, Long ida3a5, Long ida3b5, String quantity, String unit, String traceCode,
			String lineNumber, String findNumber, String referenceDesignator) {
		super();
		this.id = id;
		this.ida3a5 = ida3a5;
		this.ida3b5 = ida3b5;
		this.quantity = quantity;
		this.unit = unit;
		this.traceCode = traceCode;
		this.lineNumber = lineNumber;
		this.findNumber = findNumber;
		this.referenceDesignator = referenceDesignator;
	}

	@Override
	public String toString() {
		return "PartUsageLink [id=" + id + ", ida3a5=" + ida3a5 + ", ida3b5=" + ida3b5 + ", quantity=" + quantity
				+ ", unit=" + unit + ", traceCode=" + traceCode + ", lineNumber=" + lineNumber + ", findNumber="
				+ findNumber + ", referenceDesignator=" + referenceDesignator + "]";
	}

	public PartUsageLink() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}
