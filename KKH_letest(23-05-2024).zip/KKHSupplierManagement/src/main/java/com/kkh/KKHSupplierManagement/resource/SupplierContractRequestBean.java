package com.kkh.KKHSupplierManagement.resource;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class SupplierContractRequestBean {

	
	
	@Id
	@GeneratedValue
	Long id;
	Supplier_MasterContract supplier_MasterContract;
	Supplier_Contract1 supplier_Contract1;
	
	
	public SupplierContractRequestBean(Long id, Supplier_MasterContract savedMasterContract,
			Supplier_Contract1 savedContract1) {
		
		this.id = id;
		this.supplier_MasterContract = savedMasterContract;
		this.supplier_Contract1 = savedContract1;
	}

	public SupplierContractRequestBean(SupplierContractRequestBean bean) {
	
		this.id = bean.getId();
		this.supplier_MasterContract = bean.getSupplier_MasterContract();
		this.supplier_Contract1 =bean.getSupplier_Contract1() ;
	}

	public SupplierContractRequestBean() {
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Supplier_MasterContract getSupplier_MasterContract() {
		return supplier_MasterContract;
	}


	public void setSupplier_MasterContract(Supplier_MasterContract supplier_MasterContract) {
		this.supplier_MasterContract = supplier_MasterContract;
	}


	public Supplier_Contract1 getSupplier_Contract1() {
		return supplier_Contract1;
	}


	public void setSupplier_Contract1(Supplier_Contract1 supplier_Contract1) {
		this.supplier_Contract1 = supplier_Contract1;
	}
	
	
	
	
}
