package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
@Entity
public class Supplier_Contract1 {


	@Id
	@GeneratedValue
	private Long id;
	private String supplier_name; 
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date effective_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date expiration_date;
	private String work_scope;
	private Long masterId;
	private int iteration_info;
	private int islatest_Iteration;
	@ManyToOne
	@JoinColumn(name = "supplierContractObject")
	private Supplier_MasterContractObject supplierContractObject;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSupplier_name() {
		return supplier_name;
	}
	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}
	public Date getEffective_date() {
		return effective_date;
	}
	public void setEffective_date(Date effective_date) {
		this.effective_date = effective_date;
	}
	public Date getExpiration_date() {
		return expiration_date;
	}
	public void setExpiration_date(Date expiration_date) {
		this.expiration_date = expiration_date;
	}
	public String getWork_scope() {
		return work_scope;
	}
	public void setWork_scope(String work_scope) {
		this.work_scope = work_scope;
	}
	
	public Long getMasterId() {
		return masterId;
	}
	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}
	public int getIteration_info() {
		return iteration_info;
	}
	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}
	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}
	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}
	
	public Supplier_MasterContractObject getSupplierContractObject() {
		return supplierContractObject;
	}
	public void setSupplierContractObject(Supplier_MasterContractObject supplierContractObject) {
		this.supplierContractObject = supplierContractObject;
	}

		public Supplier_Contract1() {
		super();
		// TODO Auto-generated constructor stub
	}
		public Supplier_Contract1(Long id, String supplier_name, Date effective_date, Date expiration_date,
				String work_scope, Long masterId, int iteration_info, int islatest_Iteration,
				Supplier_MasterContractObject supplierContractObject) {
			super();
			this.id = id;
			this.supplier_name = supplier_name;
			this.effective_date = effective_date;
			this.expiration_date = expiration_date;
			this.work_scope = work_scope;
			this.masterId = masterId;
			this.iteration_info = iteration_info;
			this.islatest_Iteration = islatest_Iteration;
			this.supplierContractObject = supplierContractObject;
		}
		@Override
		public String toString() {
			return "Supplier_Contract1 [id=" + id + ", supplier_name=" + supplier_name + ", effective_date="
					+ effective_date + ", expiration_date=" + expiration_date + ", work_scope=" + work_scope
					+ ", masterId=" + masterId + ", iteration_info=" + iteration_info + ", islatest_Iteration="
					+ islatest_Iteration + ", supplierContractObject=" + supplierContractObject + "]";
		}
	
	
	
	
}
