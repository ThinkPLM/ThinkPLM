package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Supplier_ContractObject {
	
	
	@Id
	@GeneratedValue
	private Long id;
	private String supplier_name; 
	private String attachmentId;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate effective_date;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate expiration_date;
	private String work_scope;
	private Long masterId;
	private int iteration_info;
	private int islatest_Iteration;
	
	@OneToMany(mappedBy = "id")
    @Fetch(value = FetchMode.SELECT)
	private Set<Attachment> attachment = new HashSet<>();
	@ManyToOne
	@JoinColumn(name = "supplierContractObject")
	private Supplier_MasterContractObject supplierContractObject;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSupplier_name() {
		return supplier_name;
	}
	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}
	public String getWork_scope() {
		return work_scope;
	}
	public void setWork_scope(String work_scope) {
		this.work_scope = work_scope;
	}
	
	public Long getMasterId() {
		return masterId;
	}
	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}
	public int getIteration_info() {
		return iteration_info;
	}
	public void setIteration_info(int iteration_info) {
		this.iteration_info = iteration_info;
	}
	public int getIslatest_Iteration() {
		return islatest_Iteration;
	}
	public void setIslatest_Iteration(int islatest_Iteration) {
		this.islatest_Iteration = islatest_Iteration;
	}


	
	public String getAttachmentId() {
		return attachmentId;
	}
	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}
	public Set<Attachment> getAttachment() {
		return attachment;
	}
	public void setAttachment(Set<Attachment> attachment) {
		this.attachment = attachment;
	}
	
	
	public LocalDate getEffective_date() {
		return effective_date;
	}
	public void setEffective_date(LocalDate effective_date) {
		this.effective_date = effective_date;
	}
	public LocalDate getExpiration_date() {
		return expiration_date;
	}
	public void setExpiration_date(LocalDate expiration_date) {
		this.expiration_date = expiration_date;
	}
	
	public Supplier_ContractObject() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Supplier_ContractObject(Long id, String supplier_name, String attachmentId, LocalDate effective_date,
			LocalDate expiration_date, String work_scope, Long masterId, int iteration_info, int islatest_Iteration,
			Set<Attachment> attachment, Supplier_MasterContractObject supplierContractObject) {
		super();
		this.id = id;
		this.supplier_name = supplier_name;
		this.attachmentId = attachmentId;
		this.effective_date = effective_date;
		this.expiration_date = expiration_date;
		this.work_scope = work_scope;
		this.masterId = masterId;
		this.iteration_info = iteration_info;
		this.islatest_Iteration = islatest_Iteration;
		this.attachment = attachment;
		this.supplierContractObject = supplierContractObject;
	}
	@Override
	public String toString() {
		return "Supplier_ContractObject [id=" + id + ", supplier_name=" + supplier_name + ", attachmentId="
				+ attachmentId + ", effective_date=" + effective_date + ", expiration_date=" + expiration_date
				+ ", work_scope=" + work_scope + ", masterId=" + masterId + ", iteration_info=" + iteration_info
				+ ", islatest_Iteration=" + islatest_Iteration + ", attachment=" + attachment
				+ ", supplierContractObject=" + supplierContractObject + "]";
	}
	
	
	
	

	
}
