package com.kkh.KKHSupplierManagement.resource;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
@Entity
public class Supplier_MasterContractObject {

	
	
	            @Id
				@GeneratedValue
				private Long id;
	        	private String documenttype;
				private String document_number;
				private String document_name;
				private String description;
				@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
				private LocalDate createdDate;
				@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
				private LocalDate modifiedDate;
				@OneToMany(mappedBy = "masterId")
			    @Fetch(value = FetchMode.SELECT)
				private Set<Supplier_ContractObject> supplier_contract = new HashSet<>();
				public Long getId() {
					return id;
				}
				public void setId(Long id) {
					this.id = id;
				}
				public String getDocument_number() {
					return document_number;
				}
				public void setDocument_number(String document_number) {
					this.document_number = document_number;
				}
				public String getDocument_name() {
					return document_name;
				}
				public void setDocument_name(String document_name) {
					this.document_name = document_name;
				}
				public String getDescription() {
					return description;
				}
				public void setDescription(String description) {
					this.description = description;
				}
			
				public Set<Supplier_ContractObject> getSupplier_contract() {
					return supplier_contract;
				}
				public void setSupplier_contract(Set<Supplier_ContractObject> supplier_contract) {
					this.supplier_contract = supplier_contract;
				}
				public String getDocumenttype() {
					return documenttype;
				}
				public void setDocumenttype(String documenttype) {
					this.documenttype = documenttype;
				}
				public LocalDate getCreatedDate() {
					return createdDate;
				}
				public void setCreatedDate(LocalDate createdDate) {
					this.createdDate = createdDate;
				}
				public LocalDate getModifiedDate() {
					return modifiedDate;
				}
				public void setModifiedDate(LocalDate modifiedDate) {
					this.modifiedDate = modifiedDate;
				}
				
				
				
}
