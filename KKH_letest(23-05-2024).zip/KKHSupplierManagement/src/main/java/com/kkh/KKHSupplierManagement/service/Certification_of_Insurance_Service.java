package com.kkh.KKHSupplierManagement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Certification_of_insuranceRequestBean;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.SupplierPartRequestBean;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;

public interface Certification_of_Insurance_Service {

	
	
	
	public Certification_of_Insurance addCertification_of_Insurance(Certification_of_Insurance certification_of_insurance);

	public List<Certification_of_Insurance> getCertification_of_Insurances();

	public Certification_of_Insurance  getCertification_of_Insurance(Long policy_number);

	public Certification_of_Insurance updateCertification_of_Insurance(Certification_of_Insurance certification_of_insurance);

	public HttpStatus deleteCertification_of_Insurance(Long parseLong);
	
	//History
	public Certification_of_insuranceRequestBean createCertification_of_insurance(Certification_of_insuranceRequestBean certification_of_insuranceRequestBean);

	public ArrayList<Certification_of_insuranceRequestBean> getCertification_of_insurance();

	public Certification_of_Insurance_Master_Object getCertification_of_Insurance_Master_ObjectById(Long masterId);

	public Certification_of_Insurance_Master_Object createCertification_of_Insurance_Object(Certification_of_Insurance_Master_Object masterCertificationObject);

	List<Certification_of_Insurance_Master_Object> getCertification_of_Insurance_Master_Object();

	public Certification_of_Insurance_Master_Object updateCertification_of_Insurance_Object(Certification_of_Insurance_Master_Object masterCertificationObject);

	Certification_of_Insurance_Master_Object getCertificationInsuranceMasterObjectsHistoryById(Long masterId);

	public HttpStatus deleteCertificationInsuranceMasterObject(Long parseLong);
	
	public HttpStatus deleteCertificationInsuranceObjectHistoryById(Long parseLong);

	public List<Certification_of_Insurance_Master_Object> getCertification_of_Insurance_Master_ObjectBydocument_number(String document_number);

	public Certification_of_Insurance_Master_Object getCertification_of_Insurance_Master_ObjectByKeyword(String keyword);

}
