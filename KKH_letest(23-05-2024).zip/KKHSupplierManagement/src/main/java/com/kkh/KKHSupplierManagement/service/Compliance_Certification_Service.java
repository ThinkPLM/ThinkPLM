package com.kkh.KKHSupplierManagement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance;
import com.kkh.KKHSupplierManagement.resource.ComplainceCertificateRequestBean;
import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_MasterObject;
import com.kkh.KKHSupplierManagement.resource.Compliance_Certification;
import com.kkh.KKHSupplierManagement.resource.InvoiceRequestBean;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;

public interface Compliance_Certification_Service {

	
	

	public Compliance_Certification addCompliance_Certification(Compliance_Certification compliance_certification);

	public List<Compliance_Certification> getCompliance_Certifications();

	public Compliance_Certification  getCompliance_Certification(Long certification_number);

	public Compliance_Certification updateCompliance_Certification(Compliance_Certification compliance_certification);

	public HttpStatus deleteCompliance_Certification(Long parseLong);
		
	//History
			public ComplainceCertificateRequestBean createComplianceCertificate(ComplainceCertificateRequestBean complainceCertificateRequestBean);

			public ArrayList<ComplainceCertificateRequestBean> getMasterComplainceCertificate();

			public Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObjectById(Long masterId);

			public Complaince_Certificate_MasterObject createComplaince_Certificate_MasterObject(Complaince_Certificate_MasterObject masterComplaince_CertificateObject);

			List<Complaince_Certificate_MasterObject> getComplaince_Certificate_MasterObject();

			public Complaince_Certificate_MasterObject updateComplaince_Certificate_MasterObject(Complaince_Certificate_MasterObject masterComplaince_Certificate_MasterObject);

			Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObjectHistoryById(Long masterId);

			public HttpStatus deleteComplaince_Certificate_MasterObject(Long parseLong);
			
			public HttpStatus deleteComplaince_Certificate_ObjectHistoryById(Long parseLong);

			public List<Complaince_Certificate_MasterObject> getComplaince_Certificate_MasterObjectBydocument_number(String document_number);

			public Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObjectByKeyword(String keyword);

}

