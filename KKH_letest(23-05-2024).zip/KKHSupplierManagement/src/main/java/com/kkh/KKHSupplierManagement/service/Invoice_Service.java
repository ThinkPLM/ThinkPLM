package com.kkh.KKHSupplierManagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;

import com.kkh.KKHSupplierManagement.resource.Invoice;
import com.kkh.KKHSupplierManagement.resource.InvoiceRequestBean;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;

public interface Invoice_Service {

	
	public Invoice addInvoice(Invoice invoice);

	public List<Invoice> getInvoices();

	public Invoice  getInvoice(Long invoice_number);

	public Invoice updateInvoice(Invoice invoice);

	public HttpStatus deleteInvoice(Long parseLong);
	
	
	///History
		public InvoiceRequestBean createInvoice(InvoiceRequestBean invoiceRequestBean);
//
		public ArrayList<InvoiceRequestBean> getMasterInvoice();
//
		public Invoice_Master_Object getInvoice_MasterObjectsById(Long masterId);
//
		public Invoice_Master_Object createInvoice_Master_Object(Invoice_Master_Object masterInvoicesObject);
//
		List<Invoice_Master_Object> getInvoiceMasterObject();
//
		public Invoice_Master_Object updateInvoiceObject(Invoice_Master_Object masterInvoicesObject);
//
		Invoice_Master_Object getInvoiceMasterObjectsHistoryById(Long masterId);
//
		public HttpStatus deleteInvoiceMasterObject(Long parseLong);
//		
		public HttpStatus deleteInvoiceObjectsHistoryById(Long parseLong);
//
		public List<Invoice_Master_Object> getInvoice_MasterObjectByinvoice_number(String invoice_number);
//
//		 public Map<String, List<?>> globalSearch(String keyword);
		public Invoice_Master_Object getInvoice_MasterObjectsByKeyword(String keyword);
}
