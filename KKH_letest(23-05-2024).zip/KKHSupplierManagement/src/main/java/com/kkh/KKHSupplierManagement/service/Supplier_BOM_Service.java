package com.kkh.KKHSupplierManagement.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.kkh.KKHSupplierManagement.resource.KKHPartStructureResponse;
import com.kkh.KKHSupplierManagement.resource.PartUsageLink;
import com.kkh.KKHSupplierManagement.resource.Supplier_BOM;


public interface Supplier_BOM_Service {

	
public Supplier_BOM addSupplier_BOM(Supplier_BOM supplier_bom);
	
	public List<Supplier_BOM> getSupplier_BOM();
	
	public Supplier_BOM  getSupplier_BOMbyid(Long part_number);
	
	public Supplier_BOM updateSupplier_BOM(Supplier_BOM supplier_bom);
	
	public HttpStatus deleteSupplier_BOM(Long parseLong);

	public KKHPartStructureResponse getPartStructureById(Long id);

	public PartUsageLink createUsageLink(PartUsageLink usageLink);
	
//	public void deletePartStructureById(Long ida3a5,Long ida3b5);
	 public void deleteByIda3a5AndIda3b5(Long ida3a5, Long id);
	
}
 