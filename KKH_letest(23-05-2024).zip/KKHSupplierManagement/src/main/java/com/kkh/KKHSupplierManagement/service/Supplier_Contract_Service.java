package com.kkh.KKHSupplierManagement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.SupplierContractRequestBean;
import com.kkh.KKHSupplierManagement.resource.SupplierPartRequestBean;
import com.kkh.KKHSupplierManagement.resource.Supplier_Contract;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;

public interface Supplier_Contract_Service {

	
	public Supplier_Contract addSupplier_Contract(Supplier_Contract supplier_contract);
	
	public List<Supplier_Contract> getSupplier_contracts();
	
	public Supplier_Contract  getSupplier_Contract(Long document_number);
	
	public Supplier_Contract updateSupplier_Contract(Supplier_Contract supplier_contract);
	
	public HttpStatus deleteSupplier_Contract(Long parseLong);
	
	
	//History
	
	public SupplierContractRequestBean createSupplier_Contract(SupplierContractRequestBean contractRequestBean);

	public ArrayList<SupplierContractRequestBean> getSupplierMasterContract();

	public Supplier_MasterContractObject getSupplierMasterContractObjectsById(Long masterId);

	public Supplier_MasterContractObject createSupplier_ContractObject(Supplier_MasterContractObject masterContractObject);

	List<Supplier_MasterContractObject> getSupplierMasterContractObjects();

	public Supplier_MasterContractObject updateSupplier_ContractObject(Supplier_MasterContractObject masterContractObject);

	Supplier_MasterContractObject getSupplierMasterContractObjectsHistoryById(Long masterId);

	public HttpStatus deleteSupplierMasterContractObject(Long parseLong);
	
	public HttpStatus deleteSupplierContractObjectsHistoryById(Long parseLong);

	public List<Supplier_MasterContractObject> getSupplier_MasterContractObjectBydocument_number(String document_number);
	
	public Supplier_MasterContractObject getSupplier_MasterContractObjectByKeyword(String keyword);

}
