package com.kkh.KKHSupplierManagement.serviceImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.kkh.KKHSupplierManagement.Dao.AttachmentDao;
import com.kkh.KKHSupplierManagement.Dao.Certification_of_Insurance1Dao;
import com.kkh.KKHSupplierManagement.Dao.Certification_of_InsuranceDao;
import com.kkh.KKHSupplierManagement.Dao.Certification_of_Insurance_MasterDao;
import com.kkh.KKHSupplierManagement.Dao.Certification_of_Insurance_Master_ObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Certification_of_Insurance_ObjectDao;
import com.kkh.KKHSupplierManagement.Dao.InvoiceDao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplierDocumentDao;
import com.kkh.KKHSupplierManagement.resource.Attachment;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance1;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Object;
import com.kkh.KKHSupplierManagement.resource.Certification_of_insuranceRequestBean;
import com.kkh.KKHSupplierManagement.resource.Invoice;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.KKHSupplierDocument;
import com.kkh.KKHSupplierManagement.resource.SupplierPartRequestBean;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPart;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_PartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_Parts;
import com.kkh.KKHSupplierManagement.service.Certification_of_Insurance_Service;

@Service
public class Certification_of_Insurance_Serviceimpl implements Certification_of_Insurance_Service{

	@Autowired
	private AttachmentDao attachmentDao;
	@Autowired
	private	Certification_of_InsuranceDao certification_of_insuranceDao;
	@Autowired
	private	KKHSupplierDocumentDao kkhsupplierDocumentDao;
	@Autowired
	private Certification_of_Insurance1Dao certification_of_Insurance1Dao;
	@Autowired
	private Certification_of_Insurance_ObjectDao certification_of_Insurance_ObjectDao;
	@Autowired
	private Certification_of_Insurance_MasterDao certification_of_Insurance_MasterDao;
	@Autowired
	private Certification_of_Insurance_Master_ObjectDao certification_of_Insurance_Master_ObjectDao;
	
//	private  String insurance_coverage;
//	private String authorized_signatures;
	@Override
	public Certification_of_Insurance addCertification_of_Insurance(
			Certification_of_Insurance certification_of_insurance) {

		String insurance_coverage= certification_of_insurance.getInsurance_coverage();
		String authorized_signatures= certification_of_insurance.getAuthorized_signatures();
		
		KKHSupplierDocument Certification_of_Insurance_document=new KKHSupplierDocument();
		Certification_of_Insurance_document.setFileType("Certification_of_Insurance_doc");
		Certification_of_Insurance_document.setDocument(insurance_coverage);
		Certification_of_Insurance_document.setDocument(authorized_signatures);
		
KKHSupplierDocument savedoc= kkhsupplierDocumentDao.save(Certification_of_Insurance_document);
		
certification_of_insurance.setInsurance_coverage(savedoc.getId().toString());
certification_of_insurance.setAuthorized_signatures(savedoc.getId().toString());

		certification_of_insuranceDao.save(certification_of_insurance);
		return certification_of_insurance;
	}

	@Override
	public List<Certification_of_Insurance> getCertification_of_Insurances() {

		return this.certification_of_insuranceDao.findAll();
	}

	@Override
	public Certification_of_Insurance getCertification_of_Insurance(Long Policy_Number) {

		
		return certification_of_insuranceDao.getReferenceById(Policy_Number);
	}

	@Override
	public Certification_of_Insurance updateCertification_of_Insurance(
			Certification_of_Insurance certification_of_insurance) {
		certification_of_insuranceDao.save(certification_of_insurance);
		return certification_of_insurance;
	}

	@Override
	public HttpStatus deleteCertification_of_Insurance(Long parseLong) {
		if(certification_of_insuranceDao.existsById(parseLong)) {
			Certification_of_Insurance Certification_of_Insurance1 = certification_of_insuranceDao.getReferenceById(parseLong);
			certification_of_insuranceDao.delete(Certification_of_Insurance1);
			return HttpStatus.OK;
		}else {
			return HttpStatus.NOT_FOUND;
		}
	}

	//History   
	@Override
	public Certification_of_insuranceRequestBean createCertification_of_insurance(Certification_of_insuranceRequestBean certification_of_insuranceRequestBean) {

		Certification_of_Insurance_Master masterCertificate = certification_of_insuranceRequestBean.getCertification_of_Insurance_Master();
		System.out.println("masterCertificate:" + masterCertificate);
		Certification_of_Insurance1 certificate = certification_of_insuranceRequestBean.getCertification_of_Insurance1();
		System.out.println("certificate:" + certificate);
		Certification_of_Insurance_Master savedMasterCertification = certification_of_Insurance_MasterDao.save(masterCertificate);
		
		certificate.setMasterId(savedMasterCertification.getId());
		Certification_of_Insurance1 savedCertification = certification_of_Insurance1Dao.save(certificate);
		
		Certification_of_insuranceRequestBean savedCertificationBean = new Certification_of_insuranceRequestBean(savedMasterCertification.getId(), 
				savedMasterCertification, savedCertification);
		
		return savedCertificationBean;
	}

	@Override
	public ArrayList<Certification_of_insuranceRequestBean> getCertification_of_insurance() {

		List<Certification_of_Insurance_Master> masterCertificateList = certification_of_Insurance_MasterDao.findAll();
		List<Certification_of_Insurance1> certificateList = certification_of_Insurance1Dao.findAll();
		
		System.out.println("masterCertificateList:" + masterCertificateList);
		System.out.println("certificateList:" + certificateList);
		ArrayList<Certification_of_insuranceRequestBean> returnBeanList = new ArrayList<>();
		for(Certification_of_Insurance_Master master : masterCertificateList) {
			Certification_of_insuranceRequestBean bean = new Certification_of_insuranceRequestBean();
			Certification_of_Insurance1 beanCertificate = new Certification_of_Insurance1();
			bean.setId(master.getId());
			bean.setCertification_of_Insurance_Master(master);
			for(Certification_of_Insurance1 certification : certificateList) {
				if(certification.getMasterId() == master.getId()) {
					beanCertificate = certification;
				}
			}
		
			bean.setCertification_of_Insurance1(beanCertificate);
			returnBeanList.add(bean);
		}
		
		return returnBeanList;
	}

	@Override
	public Certification_of_Insurance_Master_Object getCertification_of_Insurance_Master_ObjectById(Long masterId) {
	    Certification_of_Insurance_Master_Object obj = certification_of_Insurance_Master_ObjectDao.findById(masterId).orElse(null);

	    if (obj != null) {
	        Set<Certification_of_Insurance_Object> returnCertificationSet = new HashSet<>();

	        for (Certification_of_Insurance_Object certificationObject : obj.getDocs()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = certificationObject.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                        
	                        e.printStackTrace();
	                    }
	                }
	            }

	            certificationObject.setAttachment(returnAttachmentSet);

	            if (certificationObject.getIslatest_Iteration() == 1) {
	                returnCertificationSet.add(certificationObject);
	            }
	        }

	        obj.setDocs(returnCertificationSet);
	    }

	    return obj;
	}



	@Override
	public Certification_of_Insurance_Master_Object createCertification_of_Insurance_Object(
	        Certification_of_Insurance_Master_Object masterCertificationObject) {

	    if (certification_of_Insurance_Master_ObjectDao.existsByDocumentNumber(masterCertificationObject.getDocument_number())) {
	        throw new IllegalArgumentException("Document number already exists in Certification_of_Insurance_Master_Object.");
	    }

	    if (certification_of_Insurance_Master_ObjectDao.existsByDocumentName(masterCertificationObject.getDocument_name())) {
	        throw new IllegalArgumentException("Document name already exists in Certification_of_Insurance_Master_Object.");
	    }

	    masterCertificationObject.setDocumenttype("Certification_of_Insurance");

	    Certification_of_Insurance_Master_Object savedObj = certification_of_Insurance_Master_ObjectDao.save(masterCertificationObject);

	    Set<Certification_of_Insurance_Object> certificationObjectSet = masterCertificationObject.getDocs();

	    for (Certification_of_Insurance_Object cObject : certificationObjectSet) {
	        Set<Attachment> attachmentSet = cObject.getAttachment();
	        List<Attachment> savedAttachmentSet = attachmentDao.saveAll(attachmentSet);
	        String attachedId = "";

	        for (Attachment atc : savedAttachmentSet) {
	            if (attachedId.isEmpty()) {
	                attachedId = String.valueOf(atc.getId());
	            } else {
	                attachedId += "," + atc.getId();
	            }
	        }

	        cObject.setAttachmentId(attachedId);
	        cObject.setMasterId(savedObj.getId());
	    }

	    certification_of_Insurance_ObjectDao.saveAll(certificationObjectSet);
	    return savedObj;
	}


	@Override
	public List<Certification_of_Insurance_Master_Object> getCertification_of_Insurance_Master_Object() {
	    List<Certification_of_Insurance_Master_Object> obj = certification_of_Insurance_Master_ObjectDao.findAll();

	    for (Certification_of_Insurance_Master_Object master : obj) {
	        Set<Certification_of_Insurance_Object> returnCertificationSet = new HashSet<>();

	        for (Certification_of_Insurance_Object s : master.getDocs()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setAttachment(returnAttachmentSet);

	            if (s.getIslatest_Iteration() == 1) {
	                returnCertificationSet.add(s);
	            }
	        }
	        master.setDocs(returnCertificationSet);
	    }

	    return obj;
	}


	@Override
	public Certification_of_Insurance_Master_Object updateCertification_of_Insurance_Object(
	        Certification_of_Insurance_Master_Object masterCertificationObject) {

	    try {
	        Certification_of_Insurance_Master_Object existingMasterCertificationObject = certification_of_Insurance_Master_ObjectDao
	                .getReferenceById(masterCertificationObject.getId());

	        if (existingMasterCertificationObject == null) {
	            throw new IllegalArgumentException("Master certification object does not exist with id: " + masterCertificationObject.getId());
	        }

	        Set<Certification_of_Insurance_Object> existingCertificationObjects = existingMasterCertificationObject.getDocs();
	        for (Certification_of_Insurance_Object certificationObject : existingCertificationObjects) {
	            certificationObject.setIslatest_Iteration(0);
	            certification_of_Insurance_ObjectDao.save(certificationObject);
	        }

	        for (Certification_of_Insurance_Object updatedCertificationObject : masterCertificationObject.getDocs()) {
	            updatedCertificationObject.setId(null); // Reset ID to generate a new one
	            updatedCertificationObject.setMasterId(masterCertificationObject.getId());
	            updatedCertificationObject.setIslatest_Iteration(1);
	            updatedCertificationObject.setIteration_info(updatedCertificationObject.getIteration_info() + 1);

	            Set<Attachment> attachmentSet = updatedCertificationObject.getAttachment();
	            Set<Attachment> savedAttachmentSet = new HashSet<>();
	            for (Attachment attachment : attachmentSet) {
	                if (attachment.getAttachmentType() == null) {
	                    attachment.setAttachmentType("DEFAULT_ATTACHMENT_TYPE"); 
	                }
	                Attachment savedAttachment = attachmentDao.save(attachment);
	                savedAttachmentSet.add(savedAttachment);
	            }
	            updatedCertificationObject.setAttachment(savedAttachmentSet);
	        }

	        certification_of_Insurance_ObjectDao.saveAll(masterCertificationObject.getDocs());

	        Certification_of_Insurance_Master_Object returnMasterObj = certification_of_Insurance_Master_ObjectDao.save(existingMasterCertificationObject);
	        return returnMasterObj;
	    } catch (Exception e) {
	        e.printStackTrace();
	        throw new RuntimeException("Failed to update certification of insurance object: " + e.getMessage());
	    }
	}

	@Override
	public Certification_of_Insurance_Master_Object getCertificationInsuranceMasterObjectsHistoryById(Long masterId) {
	    Certification_of_Insurance_Master_Object obj = certification_of_Insurance_Master_ObjectDao.getReferenceById(masterId);

	    Set<Certification_of_Insurance_Object> certificationObjects = obj.getDocs();

	    for (Certification_of_Insurance_Object certificationObject : certificationObjects) {
	        String attachmentIds = certificationObject.getAttachmentId();
	        if (attachmentIds != null && !attachmentIds.isEmpty()) {
	            String[] attachmentIdArray = attachmentIds.split(",");
	            Set<Attachment> attachments = new HashSet<>();
	            for (String attachmentId : attachmentIdArray) {
	                Long id = Long.parseLong(attachmentId.trim());
	                Attachment attachment = attachmentDao.getById(id);
	                if (attachment != null) {
	                    attachments.add(attachment);
	                }
	            }
	            certificationObject.setAttachment(attachments);
	        }
	    }

	    obj.setDocs(certificationObjects);

	    return obj;
	}


	@Override
	public HttpStatus deleteCertificationInsuranceMasterObject(Long parseLong) {
	    if (certification_of_Insurance_Master_ObjectDao.existsById(parseLong)) {
	        Certification_of_Insurance_Master_Object obj = certification_of_Insurance_Master_ObjectDao.getReferenceById(parseLong);

	        Set<Certification_of_Insurance_Object> certificationObjects = obj.getDocs();
	        for (Certification_of_Insurance_Object certificationObject : certificationObjects) {
	            String attachmentIds = certificationObject.getAttachmentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");
	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    Attachment attachment = attachmentDao.getById(id);
	                    if (attachment != null) {
	                        attachmentDao.delete(attachment);
	                    }
	                }
	            }
	            certification_of_Insurance_ObjectDao.delete(certificationObject);
	        }

	        certification_of_Insurance_Master_ObjectDao.delete(obj);

	        return HttpStatus.OK;
	    } else {
	        return HttpStatus.NOT_FOUND;
	    }
	}


	@Override
	public HttpStatus deleteCertificationInsuranceObjectHistoryById(Long parseLong) {
	
		if(certification_of_Insurance_ObjectDao.existsById(parseLong)) {
			Certification_of_Insurance_Object obj1 = certification_of_Insurance_ObjectDao.getReferenceById(parseLong);
			certification_of_Insurance_ObjectDao.delete(obj1);
			
			return HttpStatus.OK;
		}else {
			return HttpStatus.NOT_FOUND;
		}
		
		
		
	}

	@Override
	public List<Certification_of_Insurance_Master_Object> getCertification_of_Insurance_Master_ObjectBydocument_number(String document_number) {
	    List<Certification_of_Insurance_Master_Object> masterObjects = certification_of_Insurance_Master_ObjectDao.findByDocument_number(document_number);

	    for (Certification_of_Insurance_Master_Object obj : masterObjects) {
	        Set<Certification_of_Insurance_Object> certificationObjects = obj.getDocs();

	        for (Certification_of_Insurance_Object certificationObject : certificationObjects) {
	            String attachmentIds = certificationObject.getAttachmentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");
	                Set<Attachment> attachments = new HashSet<>();
	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    Attachment attachment = attachmentDao.getById(id);
	                    if (attachment != null) {
	                        attachments.add(attachment);
	                    }
	                }
	                certificationObject.setAttachment(attachments);
	            }
	        }

	        obj.setDocs(certificationObjects);
	    }

	    return masterObjects;
	}

	@Override
	public Certification_of_Insurance_Master_Object getCertification_of_Insurance_Master_ObjectByKeyword(
			String keyword) {

		

	   List<Certification_of_Insurance_Master_Object> matchingObjects = certification_of_Insurance_Master_ObjectDao.findByDocumentNumberOrDocumentName(keyword);

	    if (matchingObjects.isEmpty()) {
	        return null;
	    }

	    Certification_of_Insurance_Master_Object obj = matchingObjects.get(0);

	   
		    if (obj != null) {
		        Set<Certification_of_Insurance_Object> returnCertificationSet = new HashSet<>();

		        for (Certification_of_Insurance_Object certificationObject : obj.getDocs()) {
		            Set<Attachment> returnAttachmentSet = new HashSet<>();
		            String attachmentIds = certificationObject.getAttachmentId();

		            if (attachmentIds != null && !attachmentIds.isEmpty()) {
		                String[] idArray = attachmentIds.split(",");
		                for (String id : idArray) {
		                    try {
		                        Long attachmentId = Long.parseLong(id.trim());
		                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
		                        if (attachment != null) {
		                            returnAttachmentSet.add(attachment);
		                        }
		                    } catch (NumberFormatException e) {
		                        
		                        e.printStackTrace();
		                    }
		                }
		            }

		            certificationObject.setAttachment(returnAttachmentSet);

		            if (certificationObject.getIslatest_Iteration() == 1) {
		                returnCertificationSet.add(certificationObject);
		            }
		        }

		        obj.setDocs(returnCertificationSet);
		    }

		    return obj;
		}


	
	
	
	
	
}
