package com.kkh.KKHSupplierManagement.serviceImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.kkh.KKHSupplierManagement.Dao.AttachmentDao;
import com.kkh.KKHSupplierManagement.Dao.Certification_of_InsuranceDao;
import com.kkh.KKHSupplierManagement.Dao.Complaince_Certificate1Dao;
import com.kkh.KKHSupplierManagement.Dao.Complaince_Certificate_MasterDao;
import com.kkh.KKHSupplierManagement.Dao.Complaince_Certificate_MasterObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Complaince_Certificate_ObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Compliance_CertificationDao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplierDocumentDao;
import com.kkh.KKHSupplierManagement.resource.Attachment;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Object;
import com.kkh.KKHSupplierManagement.resource.ComplainceCertificateRequestBean;
import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate1;
import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_Master;
import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_MasterObject;
import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_Object;
import com.kkh.KKHSupplierManagement.resource.Compliance_Certification;
import com.kkh.KKHSupplierManagement.resource.Invoice1;
import com.kkh.KKHSupplierManagement.resource.InvoiceRequestBean;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.KKHSupplierDocument;
import com.kkh.KKHSupplierManagement.service.Compliance_Certification_Service;

@Service
public class Compliance_Certification_Serviceimpl implements Compliance_Certification_Service {

	@Autowired
	private AttachmentDao attachmentDao;
	@Autowired
	private Compliance_CertificationDao compliance_certificationDao;
	@Autowired
	private Complaince_Certificate1Dao compliance_Certification1Dao;
	@Autowired
	private Complaince_Certificate_ObjectDao complaince_Certificate_ObjectDao;
	@Autowired
	private Complaince_Certificate_MasterDao complaince_Certificate_MasterDao;
	@Autowired
	private Complaince_Certificate_MasterObjectDao complaince_Certificate_MasterObjectDao;

	@Autowired
	private KKHSupplierDocumentDao kkhsupplierDocumentDao;

//	private String compliance_standard;
//	private String certifying_authority;
//	private String compliance_statement;
	@Override
	public Compliance_Certification addCompliance_Certification(Compliance_Certification compliance_certification) {

		String compliance_standard = compliance_certification.getCompliance_standard();
		String certifying_authority = compliance_certification.getCertifying_authority();
		String compliance_statement = compliance_certification.getCompliance_statement();

		KKHSupplierDocument Compliance_Certification_document = new KKHSupplierDocument();
		Compliance_Certification_document.setFileType("Compliance_Certification_doc");
		Compliance_Certification_document.setDocument(compliance_standard);
		Compliance_Certification_document.setDocument(certifying_authority);
		Compliance_Certification_document.setDocument(compliance_statement);

		KKHSupplierDocument savedoc = kkhsupplierDocumentDao.save(Compliance_Certification_document);

		compliance_certification.setCompliance_standard(savedoc.getId().toString());
		compliance_certification.setCertifying_authority(savedoc.getId().toString());
		compliance_certification.setCompliance_statement(savedoc.getId().toString());

		compliance_certificationDao.save(compliance_certification);
		return compliance_certification;
	}

	@Override
	public List<Compliance_Certification> getCompliance_Certifications() {

		return this.compliance_certificationDao.findAll();
	}

	@Override
	public Compliance_Certification getCompliance_Certification(Long certification_number) {

		return compliance_certificationDao.getReferenceById(certification_number);
	}

	@Override
	public Compliance_Certification updateCompliance_Certification(Compliance_Certification compliance_certification) {
		compliance_certificationDao.save(compliance_certification);
		return compliance_certification;
	}

	@Override
	public HttpStatus deleteCompliance_Certification(Long parseLong) {
		if (compliance_certificationDao.existsById(parseLong)) {
			Compliance_Certification Compliance_Certification1 = compliance_certificationDao
					.getReferenceById(parseLong);
			compliance_certificationDao.delete(Compliance_Certification1);
			return HttpStatus.OK;
		} else {
			return HttpStatus.NOT_FOUND;
		}
	}

	@Override
	public ComplainceCertificateRequestBean createComplianceCertificate(
			ComplainceCertificateRequestBean complainceCertificateRequestBean) {
	
		Complaince_Certificate_Master masterComplaince_Certificate = complainceCertificateRequestBean
				.getComplaince_Certificate_Master();
		System.out.println("masterComplaince_Certificate:" + masterComplaince_Certificate);
		Complaince_Certificate1 complaince_Certificates = complainceCertificateRequestBean.getComplaince_Certificate1();
		System.out.println("complaince_Certificates:" + complaince_Certificates);
		Complaince_Certificate_Master savedmasterComplaince_Certificate = complaince_Certificate_MasterDao.save(masterComplaince_Certificate);

		complaince_Certificates.setMasterId(savedmasterComplaince_Certificate.getId());
		Complaince_Certificate1 savedcomplaince_Certificates = compliance_Certification1Dao.save(complaince_Certificates);

		ComplainceCertificateRequestBean savedComplainceCertificateBean = new ComplainceCertificateRequestBean(
				savedmasterComplaince_Certificate.getId(), savedmasterComplaince_Certificate,
				savedcomplaince_Certificates);

		return savedComplainceCertificateBean;

	}

	@Override
	public ArrayList<ComplainceCertificateRequestBean> getMasterComplainceCertificate() {
		List<Complaince_Certificate_Master> masterComplaince_CertificateList = complaince_Certificate_MasterDao
				.findAll();
		List<Complaince_Certificate1> complaince_CertificatesList = compliance_Certification1Dao.findAll();

		System.out.println("masterComplaince_CertificateList:" + masterComplaince_CertificateList);
		System.out.println("masterComplaince_CertificateList:" + masterComplaince_CertificateList);
		ArrayList<ComplainceCertificateRequestBean> returnBeanList = new ArrayList<>();
		for (Complaince_Certificate_Master master : masterComplaince_CertificateList) {
			ComplainceCertificateRequestBean bean = new ComplainceCertificateRequestBean();
			Complaince_Certificate1 beanComplaince_Certificates = new Complaince_Certificate1();
			bean.setId(master.getId());
			bean.setComplaince_Certificate_Master(master);
			for (Complaince_Certificate1 complaince_Certificates : complaince_CertificatesList) {
				if (complaince_Certificates.getMasterId() == master.getId()) {
					beanComplaince_Certificates = complaince_Certificates;
				}
			}
			bean.setComplaince_Certificate1(beanComplaince_Certificates);
			returnBeanList.add(bean);
		}

		return returnBeanList;
	}



	@Override
	public Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObjectById(Long masterId) {
	    Complaince_Certificate_MasterObject obj = complaince_Certificate_MasterObjectDao.findById(masterId).orElse(null);

	    if (obj != null) {
	        Set<Complaince_Certificate_Object> returnCertificationSet = new HashSet<>();

	        for (Complaince_Certificate_Object s : obj.getDocs()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                        // Handle invalid attachment ID format
	                        // Log or handle the exception as appropriate
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setAttachment(returnAttachmentSet);

	          
	            if (s.getIslatest_Iteration() == 1) {
	                returnCertificationSet.add(s);
	            }
	        }

	        obj.setDocs(returnCertificationSet);
	    }

	    return obj;
	}

	@Override
	public Complaince_Certificate_MasterObject createComplaince_Certificate_MasterObject(
	    Complaince_Certificate_MasterObject masterComplaince_CertificateObject) {

	    if (complaince_Certificate_MasterObjectDao.existsByDocumentNumber(masterComplaince_CertificateObject.getDocument_number())) {
	        throw new IllegalArgumentException("document number already exists in Complaince_Certificate_MasterObject.");
	    }

	    if (complaince_Certificate_MasterObjectDao.existsByDocumentName(masterComplaince_CertificateObject.getDocument_name())) {
	        throw new IllegalArgumentException("document name already exists in Complaince_Certificate_MasterObject.");
	    }

	    masterComplaince_CertificateObject.setDocumenttype("Complaince Certificate");

	    Complaince_Certificate_MasterObject savedObj = complaince_Certificate_MasterObjectDao.save(masterComplaince_CertificateObject);
	    Set<Complaince_Certificate_Object> complaince_Certificate_ObjectSet = masterComplaince_CertificateObject.getDocs();

	    for (Complaince_Certificate_Object iObject : complaince_Certificate_ObjectSet) {
	        Set<Attachment> attachmentSet = iObject.getAttachment();
	        List<Attachment> savedAttachmentSet = attachmentDao.saveAll(attachmentSet);
	        String attachedId = "";

	        for (Attachment atc : savedAttachmentSet) {
	            if (attachedId.isEmpty()) {
	                attachedId = String.valueOf(atc.getId());
	            } else {
	                attachedId += "," + atc.getId();
	            }
	        }

	        iObject.setAttachmentId(attachedId);
	        iObject.setMasterId(savedObj.getId());
	    }

	    complaince_Certificate_ObjectDao.saveAll(complaince_Certificate_ObjectSet);
	    return savedObj;
	}



	@Override
	public List<Complaince_Certificate_MasterObject> getComplaince_Certificate_MasterObject() {
	    List<Complaince_Certificate_MasterObject> obj = complaince_Certificate_MasterObjectDao.findAll();

	    for (Complaince_Certificate_MasterObject master : obj) {
	        Set<Complaince_Certificate_Object> returnComplaince_CertificatesSet = new HashSet<>();

	        for (Complaince_Certificate_Object s : master.getDocs()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                        // Handle invalid attachment ID format
	                        // Log or handle the exception as appropriate
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setAttachment(returnAttachmentSet);

	            if (s.getIslatest_Iteration() == 1) {
	                returnComplaince_CertificatesSet.add(s);
	            }
	        }
	        master.setDocs(returnComplaince_CertificatesSet);
	    }

	    return obj;
	}



	@Override
	public Complaince_Certificate_MasterObject updateComplaince_Certificate_MasterObject(
	        Complaince_Certificate_MasterObject masterComplaince_CertificateObject) {

	    try {
	        Complaince_Certificate_MasterObject existingMasterComplainceCertificateObject = complaince_Certificate_MasterObjectDao
	                .getReferenceById(masterComplaince_CertificateObject.getId());

	        if (existingMasterComplainceCertificateObject == null) {
	            
	        	throw new IllegalArgumentException("Master complaince certificate object does not exist with id: " + masterComplaince_CertificateObject.getId());
	        }

	        Set<Complaince_Certificate_Object> existingCertificateObjects = existingMasterComplainceCertificateObject.getDocs();
	        for (Complaince_Certificate_Object certificateObject : existingCertificateObjects) {
	            certificateObject.setIslatest_Iteration(0);
	            complaince_Certificate_ObjectDao.save(certificateObject);
	        }

	        Set<Complaince_Certificate_Object> updatedCertificateObjects = masterComplaince_CertificateObject.getDocs();
	        List<Complaince_Certificate_Object> savedCertificateObjects = new ArrayList<>();
	        for (Complaince_Certificate_Object updatedCertificateObject : updatedCertificateObjects) {
	           
	        	updatedCertificateObject.setId(null);
	            updatedCertificateObject.setMasterId(masterComplaince_CertificateObject.getId());
	            updatedCertificateObject.setIslatest_Iteration(1);
	            updatedCertificateObject.setIteration_info(updatedCertificateObject.getIteration_info() + 1);

	            Set<Attachment> attachmentSet = updatedCertificateObject.getAttachment();
	            Set<Attachment> savedAttachmentSet = new HashSet<>();
	            for (Attachment attachment : attachmentSet) {

	            	if (attachment.getAttachmentType() == null) {
	                    attachment.setAttachmentType("DEFAULT_ATTACHMENT_TYPE"); // Set a default attachment type

	            	}
	                Attachment savedAttachment = attachmentDao.save(attachment);
	                savedAttachmentSet.add(savedAttachment);
	            }
	            updatedCertificateObject.setAttachment(savedAttachmentSet);


	            Complaince_Certificate_Object savedCertificateObject = complaince_Certificate_ObjectDao.save(updatedCertificateObject);
	            savedCertificateObjects.add(savedCertificateObject);
	        }


	        existingMasterComplainceCertificateObject.setDocs(new HashSet<>(savedCertificateObjects));


	        Complaince_Certificate_MasterObject returnMasterObj = complaince_Certificate_MasterObjectDao.save(existingMasterComplainceCertificateObject);
	        return returnMasterObj;
	    } catch (Exception e) {

	    	e.printStackTrace(); 
	    	
	        throw new RuntimeException("Failed to update complaince certificate object: " + e.getMessage());
	    }
	}


	@Override
	public Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObjectHistoryById(Long masterId) {
	    Complaince_Certificate_MasterObject obj = complaince_Certificate_MasterObjectDao.getReferenceById(masterId);

	    Set<Complaince_Certificate_Object> certificateObjects = obj.getDocs();

	    for (Complaince_Certificate_Object certificateObject : certificateObjects) {
	        String attachmentIds = certificateObject.getAttachmentId();
	        if (attachmentIds != null && !attachmentIds.isEmpty()) {
	            String[] attachmentIdArray = attachmentIds.split(",");
	            Set<Attachment> attachments = new HashSet<>();
	            for (String attachmentId : attachmentIdArray) {
	                Long id = Long.parseLong(attachmentId.trim());
	                Attachment attachment = attachmentDao.getById(id);
	                if (attachment != null) {
	                    attachments.add(attachment);
	                }
	            }
	            certificateObject.setAttachment(attachments);
	        }
	    }

	    obj.setDocs(certificateObjects);

	    return obj;
	}



	@Override
	public HttpStatus deleteComplaince_Certificate_MasterObject(Long parseLong) {
	    if (complaince_Certificate_MasterObjectDao.existsById(parseLong)) {

	    	Complaince_Certificate_MasterObject obj = complaince_Certificate_MasterObjectDao.getReferenceById(parseLong);


	    	Set<Complaince_Certificate_Object> certificateObjects = obj.getDocs();


	    	for (Complaince_Certificate_Object certificateObject : certificateObjects) {

	    		String attachmentIds = certificateObject.getAttachmentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");

	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    Attachment attachment = attachmentDao.getById(id);
	                    if (attachment != null) {
	                        attachmentDao.delete(attachment);
	                    }
	                }
	            }

	            complaince_Certificate_ObjectDao.delete(certificateObject);
	        }


	    	complaince_Certificate_MasterObjectDao.delete(obj);

	        return HttpStatus.OK;
	    } else {
	        return HttpStatus.NOT_FOUND;
	    }
	}

	@Override
	public HttpStatus deleteComplaince_Certificate_ObjectHistoryById(Long parseLong) {
		if (complaince_Certificate_ObjectDao.existsById(parseLong)) {
			Complaince_Certificate_Object obj1 = complaince_Certificate_ObjectDao.getReferenceById(parseLong);
			complaince_Certificate_ObjectDao.delete(obj1);

			return HttpStatus.OK;
		} else {
			return HttpStatus.NOT_FOUND;
		}
	}


	@Override
	public List<Complaince_Certificate_MasterObject> getComplaince_Certificate_MasterObjectBydocument_number(String document_number) {

		List<Complaince_Certificate_MasterObject> masterObjects = complaince_Certificate_MasterObjectDao.findByDocument_number(document_number);

	    for (Complaince_Certificate_MasterObject obj : masterObjects) {
	        Set<Complaince_Certificate_Object> certificateObjects = obj.getDocs();

	        for (Complaince_Certificate_Object certificateObject : certificateObjects) {
	            String attachmentIds = certificateObject.getAttachmentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");
	                Set<Attachment> attachments = new HashSet<>();
	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    Attachment attachment = attachmentDao.getById(id);
	                    if (attachment != null) {
	                        attachments.add(attachment);
	                    }
	                }
	                certificateObject.setAttachment(attachments);
	            }
	        }

	        obj.setDocs(certificateObjects);
	    }

	    return masterObjects;
	}

	@Override
	public Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObjectByKeyword(String keyword) {


	   List<Complaince_Certificate_MasterObject> matchingObjects = complaince_Certificate_MasterObjectDao.findByDocumentNumberOrDocumentName(keyword);

	    if (matchingObjects.isEmpty()) {
	        return null;
	    }

	    Complaince_Certificate_MasterObject obj = matchingObjects.get(0);
	    
		    if (obj != null) {
		        Set<Complaince_Certificate_Object> returnCertificationSet = new HashSet<>();

		        for (Complaince_Certificate_Object s : obj.getDocs()) {
		            Set<Attachment> returnAttachmentSet = new HashSet<>();
		            String attachmentIds = s.getAttachmentId();

		            if (attachmentIds != null && !attachmentIds.isEmpty()) {
		                String[] idArray = attachmentIds.split(",");
		                for (String id : idArray) {
		                    try {
		                        Long attachmentId = Long.parseLong(id.trim());
		                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
		                        if (attachment != null) {
		                            returnAttachmentSet.add(attachment);
		                        }
		                    } catch (NumberFormatException e) {
		                        // Handle invalid attachment ID format
		                        // Log or handle the exception as appropriate
		                        e.printStackTrace();
		                    }
		                }
		            }

		            s.setAttachment(returnAttachmentSet);

		          
		            if (s.getIslatest_Iteration() == 1) {
		                returnCertificationSet.add(s);
		            }
		        }

		        obj.setDocs(returnCertificationSet);
		    }

		    return obj;
		}


}