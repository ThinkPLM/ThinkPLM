package com.kkh.KKHSupplierManagement.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.kkh.KKHSupplierManagement.Dao.AttachmentDao;
import com.kkh.KKHSupplierManagement.Dao.Invoice1Dao;
import com.kkh.KKHSupplierManagement.Dao.InvoiceDao;
import com.kkh.KKHSupplierManagement.Dao.Invoice_MasterDao;
import com.kkh.KKHSupplierManagement.Dao.Invoice_Master_ObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Invoice_ObjectDao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplierDocumentDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_MasterPartObjectDao;
import com.kkh.KKHSupplierManagement.resource.Attachment;
import com.kkh.KKHSupplierManagement.resource.Invoice;
import com.kkh.KKHSupplierManagement.resource.Invoice1;
import com.kkh.KKHSupplierManagement.resource.InvoiceRequestBean;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Invoice_Object;
import com.kkh.KKHSupplierManagement.resource.KKHSupplierDocument;
import com.kkh.KKHSupplierManagement.resource.Supplier_ContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_PartObject;
import com.kkh.KKHSupplierManagement.service.Invoice_Service;

@Service
public class Invoice_Serviceimpl implements Invoice_Service{
	@Autowired
	private AttachmentDao attachmentDao;
	@Autowired
	private	InvoiceDao invoiceDao;
	
	@Autowired
	private	Invoice1Dao invoice1Dao;
	
	@Autowired
	private	Invoice_ObjectDao invoice_ObjectDao;
	
	@Autowired
	private	Invoice_MasterDao invoice_MasterDao;
	
	@Autowired
	private	Invoice_Master_ObjectDao invoice_Master_ObjectDao;
	@Autowired
	private Supplier_MasterPartObjectDao supplier_MasterPartObjectDao;

	@Autowired
	private	KKHSupplierDocumentDao kkhsupplierDocumentDao;
//	private String itemized_charges;
//	private String payment_instructions;
	
	@Override
	public Invoice addInvoice(Invoice invoice) {

		String itemized_charges= invoice.getItemized_charges();
		String payment_instructions= invoice.getPayment_instructions();
		
		KKHSupplierDocument Invoice_document=new KKHSupplierDocument();
		Invoice_document.setFileType("Invoice_doc");
		Invoice_document.setDocument(itemized_charges);
		Invoice_document.setDocument(payment_instructions);
		
		KKHSupplierDocument savedoc= kkhsupplierDocumentDao.save(Invoice_document);
		
		invoice.setItemized_charges(savedoc.getId().toString());
		invoice.setPayment_instructions(savedoc.getId().toString());
		

		invoiceDao.save(invoice);
		return invoice;
	}

	@Override
	public List<Invoice> getInvoices() {

		return this.invoiceDao.findAll();
	}

	@Override
	public Invoice getInvoice(Long invoice_number) {
		
		return invoiceDao.getReferenceById(invoice_number);
	}

	@Override
	public Invoice updateInvoice(Invoice invoice) {
		
	invoiceDao.save(invoice);
		
		return invoice;
	}


	@Override
	public HttpStatus deleteInvoice(Long parseLong) {
		if(invoiceDao.existsById(parseLong)) {
			Invoice invoice1 = invoiceDao.getReferenceById(parseLong);
			invoiceDao.delete(invoice1);
			return HttpStatus.OK;
		}else {
			return HttpStatus.NOT_FOUND;
		}
	}

	//History
	@Override
	public InvoiceRequestBean createInvoice(InvoiceRequestBean invoiceRequestBean) {

		Invoice_Master masterInvoice = invoiceRequestBean.getInvoice_Master();
		System.out.println("masterInvoice:" + masterInvoice);
		Invoice1 invoices = invoiceRequestBean.getInvoice1();
		System.out.println("invoices:" + invoices);
		Invoice_Master savedMasterInvoice = invoice_MasterDao.save(masterInvoice);
		
		invoices.setMasterId(savedMasterInvoice.getId());
		Invoice1 savedInvoices = invoice1Dao.save(invoices);
		
		InvoiceRequestBean savedInvoiceBean = new InvoiceRequestBean(savedMasterInvoice.getId(), 
				savedMasterInvoice, savedInvoices);
		
		return savedInvoiceBean;
		
		
	}

	@Override
	public ArrayList<InvoiceRequestBean> getMasterInvoice() {
		
		
			List<Invoice_Master> masterInvoicesList = invoice_MasterDao.findAll();
			List<Invoice1> invoicesList = invoice1Dao.findAll();
			
			System.out.println("masterInvoicesList:" + masterInvoicesList);
			System.out.println("invoicesList:" + invoicesList);
			ArrayList<InvoiceRequestBean> returnBeanList = new ArrayList<>();
			for(Invoice_Master master : masterInvoicesList) {
				InvoiceRequestBean bean = new InvoiceRequestBean();
				Invoice1 beanInvoices = new Invoice1();
				bean.setId(master.getId());
				bean.setInvoice_Master(master);
				for(Invoice1 invoices: invoicesList) {
					if(invoices.getMasterId() == master.getId()) {
						beanInvoices = invoices;
					}
				}
				bean.setInvoice1(beanInvoices);
				returnBeanList.add(bean);
			}
			
			return returnBeanList;
		}

	@Override
	public Invoice_Master_Object getInvoice_MasterObjectsById(Long masterId) {
	
	Invoice_Master_Object obj = invoice_Master_ObjectDao.findById(masterId).orElse(null);

	    if (obj != null) {
	        Set<Invoice_Object> returnContractSet = new HashSet<>();

	        for (Invoice_Object s : obj.getInvoice_Doc()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                     
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setAttachment(returnAttachmentSet);

	            if (s.getIslatest_Iteration() == 1) {
	                returnContractSet.add(s);
	            }
	        }

	        obj.setInvoice_Doc(returnContractSet);
	    }

	    return obj;
	}
	
	

	@Override
	public Invoice_Master_Object createInvoice_Master_Object(Invoice_Master_Object masterInvoicesObject) {
	    if (invoice_Master_ObjectDao.existsByInvoiceNumber(masterInvoicesObject.getInvoice_number())) {
	       
	        throw new IllegalArgumentException("Invoice number already exists in Invoice_Master_Object.");
	    }

	    if (invoice_Master_ObjectDao.existsByInvoiceName(masterInvoicesObject.getInvoice_name())) {
	       
	        throw new IllegalArgumentException("Invoice name already exists in Invoice_Master_Object.");
	    }

	 
	    masterInvoicesObject.setDocumenttype("Invoice");

	    Invoice_Master_Object savedObj = invoice_Master_ObjectDao.save(masterInvoicesObject);

	    Set<Invoice_Object> supplier_ContractObjectSet = masterInvoicesObject.getInvoice_Doc();

	    for (Invoice_Object sObject : supplier_ContractObjectSet) {
	        Set<Attachment> attachmentSet = sObject.getAttachment();
	        List<Attachment> savedattachmentSet = attachmentDao.saveAll(attachmentSet);
	        String attachedId = "";

	        for (Attachment atc : savedattachmentSet) {
	            if (attachedId.isEmpty()) {
	                attachedId = String.valueOf(atc.getId());
	            } else {
	                attachedId = attachedId + "," + String.valueOf(atc.getId());
	            }
	        }

	        sObject.setAttachmentId(attachedId);
	        sObject.setMasterId(savedObj.getId());
	    }

	    invoice_ObjectDao.saveAll(supplier_ContractObjectSet);
	    return savedObj;
	}

	
	
	
	@Override
	public List<Invoice_Master_Object> getInvoiceMasterObject() {


	    List<Invoice_Master_Object> obj = invoice_Master_ObjectDao.findAll();

	    for (Invoice_Master_Object master : obj) {
	        Set<Invoice_Object> returnContractSet = new HashSet<>();

	        for (Invoice_Object s : master.getInvoice_Doc()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                       
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setAttachment(returnAttachmentSet);

	            if (s.getIslatest_Iteration() == 1) {
	                returnContractSet.add(s);
	            }
	        }
	        master.setInvoice_Doc(returnContractSet);
	    }

	    return obj;
	}
	
	
	@Override
	public Invoice_Master_Object updateInvoiceObject(Invoice_Master_Object masterInvoicesObject) {

	  try {
			  Invoice_Master_Object existingMasterContractObject = invoice_Master_ObjectDao
		                .getReferenceById(masterInvoicesObject.getId());

		        if (existingMasterContractObject == null) {
		            throw new IllegalArgumentException("Master Invoice object does not exist with id: " + masterInvoicesObject.getId());
		        }

		        Set<Invoice_Object> existingContractObjects = existingMasterContractObject.getInvoice_Doc();
		        for (Invoice_Object contractObject : existingContractObjects) {
		            contractObject.setIslatest_Iteration(0);
		            invoice_ObjectDao.save(contractObject);
		        }

		        Set<Invoice_Object> updatedContractObjects = masterInvoicesObject.getInvoice_Doc();
		        List<Invoice_Object> savedContractObjects = new ArrayList<>();
		        for (Invoice_Object updatedContractObject : updatedContractObjects) {

		        	updatedContractObject.setId(null);
		            updatedContractObject.setMasterId(masterInvoicesObject.getId());
		            updatedContractObject.setIslatest_Iteration(1);
		            updatedContractObject.setIteration_info(updatedContractObject.getIteration_info() + 1);

		          
		            Set<Attachment> attachmentSet = updatedContractObject.getAttachment();
		            Set<Attachment> savedAttachmentSet = new HashSet<>();
		            for (Attachment attachment : attachmentSet) {
		     
		                if (attachment.getAttachmentType() == null) {
		                    attachment.setAttachmentType("DEFAULT_ATTACHMENT_TYPE"); 
		                  
		                }
		                Attachment savedAttachment = attachmentDao.save(attachment);
		                savedAttachmentSet.add(savedAttachment);
		            }
		            updatedContractObject.setAttachment(savedAttachmentSet);

		           
		            Invoice_Object savedContractObject = invoice_ObjectDao.save(updatedContractObject);
		            savedContractObjects.add(savedContractObject);
		        }

		      
		        existingMasterContractObject.setInvoice_Doc(new HashSet<>(savedContractObjects));

		        
		        Invoice_Master_Object returnMasterObj = invoice_Master_ObjectDao.save(existingMasterContractObject);
		        return returnMasterObj;
		    } catch (Exception e) {
		        e.printStackTrace(); 
		        throw new RuntimeException("Failed to update Invoice object: " + e.getMessage());
		    }
		}

	

//	@Override
//	public Invoice_Master_Object getInvoiceMasterObjectsHistoryById(Long masterId) {
//
//		Invoice_Master_Object obj = invoice_Master_ObjectDao.getReferenceById(masterId);
//
//		    Set<Invoice_Object> contractObjects = obj.getInvoice_Doc();
//
//		    for (Invoice_Object contractObject : contractObjects) {
//		        String attachmentIds = contractObject.getAttachmentId();
//		        if (attachmentIds != null && !attachmentIds.isEmpty()) {
//		            String[] attachmentIdArray = attachmentIds.split(",");
//		            Set<Attachment> attachments = new HashSet<>();
//		            for (String attachmentId : attachmentIdArray) {
//		                Long id = Long.parseLong(attachmentId.trim());
//		                Attachment attachment = attachmentDao.getById(id);
//		                if (attachment != null) {
//		                    attachments.add(attachment);
//		                }
//		            }
//		            contractObject.setAttachment(attachments);
//		        }
//		    }
//
//		    obj.setInvoice_Doc(contractObjects);
//
//		    return obj;
//		}
	@Override
	public Invoice_Master_Object getInvoiceMasterObjectsHistoryById(Long masterId) {

	    Invoice_Master_Object obj = invoice_Master_ObjectDao.getReferenceById(masterId);

	    Set<Invoice_Object> invoiceObjects = obj.getInvoice_Doc();

	    for (Invoice_Object invoiceObject : invoiceObjects) {
	        String attachmentIds = invoiceObject.getAttachmentId();
	        if (attachmentIds != null && !attachmentIds.isEmpty()) {
	            String[] attachmentIdArray = attachmentIds.split(",");
	            Set<Attachment> attachments = new HashSet<>();
	            for (String attachmentId : attachmentIdArray) {
	                Long id = Long.parseLong(attachmentId.trim());
	                Attachment attachment = attachmentDao.getById(id);
	                if (attachment != null) {
	                    attachments.add(attachment);
	                }
	            }
	            invoiceObject.setAttachment(attachments);
	        }
	    }

	    obj.setInvoice_Doc(invoiceObjects);

	    return obj;
	}

	@Override
	public HttpStatus deleteInvoiceMasterObject(Long parseLong) {


		  if (invoice_Master_ObjectDao.existsById(parseLong)) {
			  Invoice_Master_Object obj = invoice_Master_ObjectDao.getReferenceById(parseLong);
		        
		        Set<Invoice_Object> contractObjects = obj.getInvoice_Doc();
		        
		        for (Invoice_Object contractObject : contractObjects) {
		            String attachmentIds = contractObject.getAttachmentId();
		            if (attachmentIds != null && !attachmentIds.isEmpty()) {
		                String[] attachmentIdArray = attachmentIds.split(",");
		                for (String attachmentId : attachmentIdArray) {
		                    Long id = Long.parseLong(attachmentId.trim());
		                    Attachment attachment = attachmentDao.getById(id);
		                    if (attachment != null) {
		                        attachmentDao.delete(attachment);
		                    }
		                }
		            }
		            invoice_ObjectDao.delete(contractObject);
		        }
		        
		        invoice_Master_ObjectDao.delete(obj);
		        
		        return HttpStatus.OK;
		    } else {
		        return HttpStatus.NOT_FOUND;
		    }
		}

	@Override
	public HttpStatus deleteInvoiceObjectsHistoryById(Long parseLong) {
		
		if(invoice_ObjectDao.existsById(parseLong)) {
			Invoice_Object obj1 = invoice_ObjectDao.getReferenceById(parseLong);
			invoice_ObjectDao.delete(obj1);
			
			return HttpStatus.OK;
		}else {
			return HttpStatus.NOT_FOUND;
		}	}

	@Override
	public List<Invoice_Master_Object> getInvoice_MasterObjectByinvoice_number(String invoice_number) {

	    List<Invoice_Master_Object> masterContractObjects = invoice_Master_ObjectDao.findByInvoice_number(invoice_number);
	    
	    for (Invoice_Master_Object obj : masterContractObjects) {
	        Set<Invoice_Object> contractObjects = obj.getInvoice_Doc();
	        
	        for (Invoice_Object contractObject : contractObjects) {
	            String attachmentIds = contractObject.getAttachmentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");
	                Set<Attachment> attachments = new HashSet<>();
	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    Attachment attachment = attachmentDao.getById(id);
	                    if (attachment != null) {
	                        attachments.add(attachment);
	                    }
	                }
	                contractObject.setAttachment(attachments);
	            }
	        }
	        
	        obj.setInvoice_Doc(contractObjects);
	    }
	    
	    return masterContractObjects;
	}
	
	
//	
//	 public Map<String, List<?>> globalSearch(String keyword) {
//	        Map<String, List<?>> results = new HashMap<>();
//	        List<Invoice_Master_Object> users = invoice_Master_ObjectDao.searchByInvoiceNumberOrInvoiceName(keyword);
//	        List<Supplier_MasterPartObject> products = supplier_MasterPartObjectDao.searchByPartNumberOrPartName(keyword);
//
//	        results.put("users", users);
//	        results.put("products", products);
//
//	        return results;
//	    }

	@Override
	public Invoice_Master_Object getInvoice_MasterObjectsByKeyword(String keyword) {

	    List<Invoice_Master_Object> matchingObjects = invoice_Master_ObjectDao.findByInvoiceNumberOrInvoiceName(keyword);

	    if (matchingObjects.isEmpty()) {
	        return null;
	    }

	    Invoice_Master_Object obj = matchingObjects.get(0);

	    if (obj != null) {
	        Set<Invoice_Object> returnContractSet = new HashSet<>();

	        for (Invoice_Object s : obj.getInvoice_Doc()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setAttachment(returnAttachmentSet);

	            if (s.getIslatest_Iteration() == 1) {
	                returnContractSet.add(s);
	            }
	        }

	        obj.setInvoice_Doc(returnContractSet);
	    }

	    return obj;
	}

	
}































