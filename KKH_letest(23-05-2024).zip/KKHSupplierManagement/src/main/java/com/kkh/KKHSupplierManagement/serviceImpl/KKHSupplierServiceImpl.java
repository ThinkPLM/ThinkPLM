package com.kkh.KKHSupplierManagement.serviceImpl;



import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.kkh.KKHSupplierManagement.Dao.KKHSupplier1Dao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplierDao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplierDocumentDao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplier_MasterDao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplier_MasterObjectDao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplier_ObjectDao;
import com.kkh.KKHSupplierManagement.resource.Attachment;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.KKHSupplier;
import com.kkh.KKHSupplierManagement.resource.KKHSupplier1;
import com.kkh.KKHSupplierManagement.resource.KKHSupplierDocument;
import com.kkh.KKHSupplierManagement.resource.KKHSupplierRequestBean;
import com.kkh.KKHSupplierManagement.resource.KKHSupplier_Master;
import com.kkh.KKHSupplierManagement.resource.KKHSupplier_MasterObject;
import com.kkh.KKHSupplierManagement.resource.KKHSupplier_Object;
import com.kkh.KKHSupplierManagement.resource.Supplier_ContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterContractObject;
import com.kkh.KKHSupplierManagement.service.KKHSupplierService;

@Service
public class KKHSupplierServiceImpl implements KKHSupplierService {

	@Autowired
	private	KKHSupplierDao supplierDao;
	@Autowired
	private	KKHSupplier1Dao supplier1Dao;
	@Autowired
	private	KKHSupplier_ObjectDao kkhsupplier_ObjectDao;
	@Autowired
	private	KKHSupplier_MasterObjectDao kkhsupplier_MasterObjectDao;
	@Autowired
	private	KKHSupplier_MasterDao kkhsupplier_MasterDao;
	

	@Autowired
	private KKHSupplierDocumentDao kkhsupplierDocumentDao;

	@Override
	public KKHSupplier addSupplierDetails(KKHSupplier kkhSupplierBean) {

		KKHSupplier savedObj = supplierDao.save(kkhSupplierBean);
		
		
		
		List<KKHSupplierDocument> doc = savedObj.getDocument();
		List<KKHSupplierDocument> savedattachmentSet = kkhsupplierDocumentDao.saveAll(doc);
		String attachedId = "";
		for (KKHSupplierDocument atc : savedattachmentSet) {
			if (attachedId == "") {
				attachedId = String.valueOf(atc.getId());
			}

			else {
				attachedId = attachedId + "," + String.valueOf(atc.getId());

			}
		}
		kkhSupplierBean.setDocumentId(attachedId);
		String obj = kkhSupplierBean.getDocumentId();
		System.out.println(
				"**" + savedattachmentSet.toString().substring(1, savedattachmentSet.toString().length() - 1));
	
	
		
		kkhsupplierDocumentDao.saveAll(doc);
		return savedObj;
	}
	


	@Override
	public List<KKHSupplier> getSuppliers() {
	    List<KKHSupplier> suppliers = this.supplierDao.findAll();

	   
	    for (KKHSupplier supplier : suppliers) {
	        String documentIds = supplier.getDocumentId();
	        if (documentIds != null && !documentIds.isEmpty()) {
	            String[] documentIdArray = documentIds.split(",");
	            List<KKHSupplierDocument> documents = new ArrayList<>();
	            for (String documentId : documentIdArray) {
	                KKHSupplierDocument document = kkhsupplierDocumentDao.findById(Long.parseLong(documentId)).orElse(null);
	                if (document != null) {
	                    documents.add(document);
	                }
	            }
	            supplier.setDocument(documents);
	        }
	    }
	    return suppliers;
	}



	
	@Override
	public KKHSupplier getSupplier(Long supplierId) {
	    KKHSupplier supplier = supplierDao.findById(supplierId).orElse(null);
	    
	    if (supplier != null) {
	        String documentIds = supplier.getDocumentId();
	        
	        if (documentIds != null && !documentIds.isEmpty()) {
	            String[] documentIdArray = documentIds.split(",");
	            List<KKHSupplierDocument> documents = new ArrayList<>();
	            for (String documentId : documentIdArray) {
	                try {
	                    Long id = Long.parseLong(documentId.trim()); // Trim to remove leading/trailing whitespaces
	                    KKHSupplierDocument document = kkhsupplierDocumentDao.findById(id).orElse(null);
	                    if (document != null) {
	                        documents.add(document);
	                    } else {
	                        System.out.println("Document with ID " + id + " not found for supplier " + supplierId);
	                    }
	                } catch (NumberFormatException e) {
	                    System.out.println("Error parsing document ID: " + documentId);
	                }
	            }
	            supplier.setDocument(documents);
	        }
	    }
	    return supplier;
	}



	@Override
	public KKHSupplier updateSupplier(KKHSupplier kkhSupplierBean) {
	    KKHSupplier existingSupplier = supplierDao.findById(kkhSupplierBean.getId()).orElse(null);

	    if (existingSupplier == null) {
	        throw new IllegalArgumentException("Supplier not found with id: " + kkhSupplierBean.getId());
	    }

	    existingSupplier.setName(kkhSupplierBean.getName());
	    existingSupplier.setCategory(kkhSupplierBean.getCategory());
	    existingSupplier.setEmail(kkhSupplierBean.getEmail());
	    existingSupplier.setContact(kkhSupplierBean.getContact());
	    existingSupplier.setPt(kkhSupplierBean.getPt());
	    existingSupplier.setCreatedDate(kkhSupplierBean.getCreatedDate());
	    existingSupplier.setModifiedDate(kkhSupplierBean.getModifiedDate());
	    existingSupplier.setCountry(kkhSupplierBean.getCountry());
	    existingSupplier.setState(kkhSupplierBean.getState());
	    existingSupplier.setDistrict(kkhSupplierBean.getDistrict());
	    existingSupplier.setLocation(kkhSupplierBean.getLocation());
	    existingSupplier.setStart_date(kkhSupplierBean.getStart_date());
	    existingSupplier.setEnd_date(kkhSupplierBean.getEnd_date());

	    List<KKHSupplierDocument> updatedDocuments = kkhSupplierBean.getDocument();
	    if (updatedDocuments != null && !updatedDocuments.isEmpty()) {
	        List<KKHSupplierDocument> existingDocuments = existingSupplier.getDocument();
	        if (existingDocuments != null) {
	            existingDocuments.removeIf(doc -> !updatedDocuments.contains(doc));
	        }
	        List<KKHSupplierDocument> savedDocuments = new ArrayList<>();
	        for (KKHSupplierDocument updatedDocument : updatedDocuments) {
	            if (updatedDocument.getId() == null) {
	                updatedDocument.setId(null); 
	            }
	            KKHSupplierDocument savedDocument = kkhsupplierDocumentDao.save(updatedDocument);
	            savedDocuments.add(savedDocument);
	        }
	        existingSupplier.setDocument(savedDocuments);
	    }

	    KKHSupplier savedSupplier = supplierDao.save(existingSupplier);
	    return savedSupplier;
	}


	



	@Override
	public HttpStatus deleteSupplier(Long supplierId) {
	    KKHSupplier supplier = supplierDao.getOne(supplierId); // Adjusted to directly return the entity
	    
	    if (supplier != null) {
	        List<KKHSupplierDocument> documents = supplier.getDocument();
	        if (documents != null && !documents.isEmpty()) {
	            for (KKHSupplierDocument document : documents) {
	                kkhsupplierDocumentDao.deleteById(document.getId());
	            }
	        }
	        
	        supplierDao.deleteById(supplierId);
	        
	        return HttpStatus.OK;
	    } else {
	        return HttpStatus.NOT_FOUND;
	    }
	}


	

	
	

	@Override
	public List<KKHSupplier> getSupplierCategory(String category) {
	    List<KKHSupplier> suppliers = supplierDao.findByCategory(category);

	    for (KKHSupplier supplier : suppliers) {
	        String documentIds = supplier.getDocumentId();

	        if (documentIds != null && !documentIds.isEmpty()) {
	            String[] documentIdArray = documentIds.split(",");
	            List<KKHSupplierDocument> documents = new ArrayList<>();
	            for (String documentId : documentIdArray) {
	                try {
	                    Long id = Long.parseLong(documentId.trim()); 
	                    KKHSupplierDocument document = kkhsupplierDocumentDao.getById(id);
	                    if (document != null) {
	                        documents.add(document);
	                    }
	                } catch (NumberFormatException e) {
	                    System.out.println("Error parsing document ID: " + documentId);
	                }
	            }
	            supplier.setDocument(documents);
	        }
	    }

	    return suppliers;
	}


	//History
	@Override
	public KKHSupplierRequestBean createSupplier(KKHSupplierRequestBean kkhsupplierRequestBean) {

		KKHSupplier_Master kkhsupplier_Master = kkhsupplierRequestBean.getKkhsupplier_Master();
		System.out.println("kkhsupplier_Master:" + kkhsupplier_Master);
		KKHSupplier1 kkhsupplier1 = kkhsupplierRequestBean.getKkhsupplier1();
		System.out.println("kkhsupplier1:" + kkhsupplier1);
		KKHSupplier_Master savedkkhsupplier_Master = kkhsupplier_MasterDao.save(kkhsupplier_Master);
		
		kkhsupplier1.setMasterId(savedkkhsupplier_Master.getId());;
		KKHSupplier1 savedkkhsupplier1 = supplier1Dao.save(kkhsupplier1);
		
		KKHSupplierRequestBean savedBean = new KKHSupplierRequestBean(savedkkhsupplier_Master.getId(), 
				savedkkhsupplier_Master, kkhsupplier1);
		
		return null;
	}
	

	@Override
	public ArrayList<KKHSupplierRequestBean> getSupplierMaster() {

		List<KKHSupplier_Master> mastersupplierList = kkhsupplier_MasterDao.findAll();
		List<KKHSupplier1> KKHSupplier1List = supplier1Dao.findAll();
		
		System.out.println("mastersupplierList:" + mastersupplierList);
		System.out.println("KKHSupplier1List:" + KKHSupplier1List);
		ArrayList<KKHSupplierRequestBean> returnBeanList = new ArrayList<>();
		for(KKHSupplier_Master master : mastersupplierList) {
			KKHSupplierRequestBean bean = new KKHSupplierRequestBean();
			KKHSupplier1 beanSupplier1 = new KKHSupplier1();
			bean.setId(master.getId());
			bean.setKkhsupplier_Master(master);
			for(KKHSupplier1 supplier1 : KKHSupplier1List) {
				if(supplier1.getMasterId() == master.getId()) {
					beanSupplier1 = supplier1;
				}
			}
			bean.setKkhsupplier1(beanSupplier1);
			returnBeanList.add(bean);
		}
		
		return returnBeanList;
	}


	@Override
	public KKHSupplier_MasterObject getKKHSupplierMasterObjectsById(Long masterId) {
	    KKHSupplier_MasterObject obj = kkhsupplier_MasterObjectDao.findById(masterId).orElse(null);

	    if (obj != null) {
	        Set<KKHSupplier_Object> returnSupplierSet = new HashSet<>();

	        for (KKHSupplier_Object s : obj.getSupplier()) {
	            Set<KKHSupplierDocument> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getDocumentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        KKHSupplierDocument attachment = kkhsupplierDocumentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                       
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setDocument(returnAttachmentSet);
	            if (s.getIslatest_Iteration() == 1) {
	                returnSupplierSet.add(s);
	            }
	        }

	        obj.setSupplier(returnSupplierSet);
	    }

	    return obj;
	}

	
	@Override
	public List<KKHSupplier_MasterObject> getKKHSupplier_MasterObject() {
	    List<KKHSupplier_MasterObject> obj = kkhsupplier_MasterObjectDao.findAll();

	    for (KKHSupplier_MasterObject master : obj) {
	        Set<KKHSupplier_Object> returnSupplierSet = new HashSet<>();

	        for (KKHSupplier_Object s : master.getSupplier()) {
	            Set<KKHSupplierDocument> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getDocumentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        KKHSupplierDocument attachment = kkhsupplierDocumentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setDocument(returnAttachmentSet);
	            if (s.getIslatest_Iteration() == 1) {
		            returnSupplierSet.add(s);
	            }
	        }
	        master.setSupplier(returnSupplierSet);
	    }

	    return obj;
	}


	@Override
	public KKHSupplier_MasterObject createSupplier_Object(KKHSupplier_MasterObject kkhsupplier_MasterObject) {

	    

	    if (kkhsupplier_MasterObjectDao.existsByName(kkhsupplier_MasterObject.getName())) {
	        throw new IllegalArgumentException("supplier name already exists in KKHSupplier_MasterObject.");
	    }

	    KKHSupplier_MasterObject savedObj = kkhsupplier_MasterObjectDao.save(kkhsupplier_MasterObject);
	    
	    Set<KKHSupplier_Object> kkhsupplier_ObjectSet = kkhsupplier_MasterObject.getSupplier();
	    
	    for (KKHSupplier_Object sObject : kkhsupplier_ObjectSet) {
	        Set<KKHSupplierDocument> attachmentSet = sObject.getDocument();
	        List<KKHSupplierDocument> savedAttachmentSet = kkhsupplierDocumentDao.saveAll(attachmentSet);
	        String attachedId = "";

	        for (KKHSupplierDocument atc : savedAttachmentSet) {
	            if (attachedId.isEmpty()) {
	                attachedId = String.valueOf(atc.getId());
	            } else {
	                attachedId += "," + atc.getId();
	            }
	        }

	        sObject.setDocumentId(attachedId);
	        sObject.setMasterId(savedObj.getId());
	    }

	    kkhsupplier_ObjectDao.saveAll(kkhsupplier_ObjectSet);
	    return savedObj;
	}


	
	@Override
	public KKHSupplier_MasterObject updateKKHSupplier_Object(KKHSupplier_MasterObject kkhsupplier_MasterObject) {

	    try {
	        KKHSupplier_MasterObject existingMasterObject = kkhsupplier_MasterObjectDao
	                .getReferenceById(kkhsupplier_MasterObject.getId());

	        if (existingMasterObject == null) {
	            throw new IllegalArgumentException("Master object does not exist with id: " + kkhsupplier_MasterObject.getId());
	        }

	        Set<KKHSupplier_Object> existingObjects = existingMasterObject.getSupplier();

	        for (KKHSupplier_Object existingObject : existingObjects) {
	            existingObject.setIslatest_Iteration(0);
	            kkhsupplier_ObjectDao.save(existingObject);
	        }

	        List<KKHSupplier_Object> savedObjects = new ArrayList<>();

	        for (KKHSupplier_Object updatedObject : kkhsupplier_MasterObject.getSupplier()) {
	            updatedObject.setId(null); 
	            updatedObject.setMasterId(kkhsupplier_MasterObject.getId());
	            updatedObject.setIslatest_Iteration(1);
	            updatedObject.setIteration_info(updatedObject.getIteration_info() + 1);

	            Set<KKHSupplierDocument> attachmentSet = updatedObject.getDocument();
	            Set<KKHSupplierDocument> savedAttachmentSet = new HashSet<>();
	            for (KKHSupplierDocument attachment : attachmentSet) {
	                if (attachment.getFileType() == null) {
	                    attachment.setFileType("Document"); 
	                }
	                KKHSupplierDocument savedAttachment = kkhsupplierDocumentDao.save(attachment);
	                savedAttachmentSet.add(savedAttachment);
	            }
	            updatedObject.setDocument(savedAttachmentSet);

	            KKHSupplier_Object savedObject = kkhsupplier_ObjectDao.save(updatedObject);
	            savedObjects.add(savedObject);
	        }

	        existingMasterObject.setSupplier(new HashSet<>(savedObjects));
	        KKHSupplier_MasterObject returnMasterObj = kkhsupplier_MasterObjectDao.save(existingMasterObject);

	        return returnMasterObj;
	    } catch (Exception e) {
	        e.printStackTrace();
	        throw new RuntimeException("Failed to update KKH supplier object: " + e.getMessage());
	    }
	}


	@Override
	public KKHSupplier_MasterObject getKKHSupplier_MasterObjectHistoryById(Long masterId) {
	    KKHSupplier_MasterObject obj = kkhsupplier_MasterObjectDao.getReferenceById(masterId);

	    Set<KKHSupplier_Object> supplierObjects = obj.getSupplier();

	    for (KKHSupplier_Object supplierObject : supplierObjects) {
	        String attachmentIds = supplierObject.getDocumentId();
	        if (attachmentIds != null && !attachmentIds.isEmpty()) {
	            String[] attachmentIdArray = attachmentIds.split(",");
	            Set<KKHSupplierDocument> attachments = new HashSet<>();
	            for (String attachmentId : attachmentIdArray) {
	                Long id = Long.parseLong(attachmentId.trim());
	                KKHSupplierDocument attachment = kkhsupplierDocumentDao.getById(id);
	                if (attachment != null) {
	                    attachments.add(attachment);
	                }
	            }
	            supplierObject.setDocument(attachments);
	        }
	    }

	    obj.setSupplier(supplierObjects);

	    return obj;
	}


	
	@Override
	public HttpStatus deleteKKHSupplier_MasterObject(Long parseLong) {
	    if (kkhsupplier_MasterObjectDao.existsById(parseLong)) {
	        KKHSupplier_MasterObject obj = kkhsupplier_MasterObjectDao.getReferenceById(parseLong);

	        Set<KKHSupplier_Object> supplierObjects = obj.getSupplier();

	        for (KKHSupplier_Object supplierObject : supplierObjects) {

	        	String attachmentIds = supplierObject.getDocumentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");
	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    KKHSupplierDocument attachment = kkhsupplierDocumentDao.getById(id);
	                    if (attachment != null) {
	                    	kkhsupplierDocumentDao.delete(attachment);
	                    }
	                }
	            }
	            kkhsupplier_ObjectDao.delete(supplierObject);
	        }

	        kkhsupplier_MasterObjectDao.delete(obj);

	        return HttpStatus.OK;
	    } else {
	        return HttpStatus.NOT_FOUND;
	    }
	}

	@Override
	public HttpStatus deleteKKHSupplier_ObjectHistoryById(Long parseLong) {

		if(kkhsupplier_ObjectDao.existsById(parseLong)) {
			KKHSupplier_Object obj1 = kkhsupplier_ObjectDao.getReferenceById(parseLong);
			kkhsupplier_ObjectDao.delete(obj1);
			
			return HttpStatus.OK;
		}else {
			return HttpStatus.NOT_FOUND;
		}
		
		
		
	}
	
	

	@Override
	public List<KKHSupplier_MasterObject> getKKHSupplier_MasterObjectByname(String name) {
	    List<KKHSupplier_MasterObject> masterObjects = kkhsupplier_MasterObjectDao.findByName(name);

	    for (KKHSupplier_MasterObject obj : masterObjects) {
	        Set<KKHSupplier_Object> supplierObjects = obj.getSupplier();

	        for (KKHSupplier_Object supplierObject : supplierObjects) {
	            String attachmentIds = supplierObject.getDocumentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");
	                Set<KKHSupplierDocument> attachments = new HashSet<>();
	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    KKHSupplierDocument attachment = kkhsupplierDocumentDao.getById(id);
	                    if (attachment != null) {
	                        attachments.add(attachment);
	                    }
	                }
	                supplierObject.setDocument(attachments);
	            }
	        }

	        obj.setSupplier(supplierObjects);
	    }

	    return masterObjects;
	}


	@Override
	public List<KKHSupplier_MasterObject> getSupplierbyCategory(String category) {
	    List<KKHSupplier_MasterObject> masterObjects = kkhsupplier_MasterObjectDao.findByCategory(category);

	    for (KKHSupplier_MasterObject obj : masterObjects) {
	        Set<KKHSupplier_Object> supplierObjects = obj.getSupplier();

	        for (KKHSupplier_Object supplierObject : supplierObjects) {
	            String attachmentIds = supplierObject.getDocumentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");
	                Set<KKHSupplierDocument> attachments = new HashSet<>();
	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    KKHSupplierDocument attachment = kkhsupplierDocumentDao.getById(id);
	                    if (attachment != null) {
	                        attachments.add(attachment);
	                    }
	                }
	                supplierObject.setDocument(attachments);
	            }
	        }

	        obj.setSupplier(supplierObjects);
	    }

	    return masterObjects;
	}



	@Override
	public KKHSupplier_MasterObject getKKHSupplier_MasterObjectByKeyword(String keyword) {
	
		 List<KKHSupplier_MasterObject> matchingObjects = kkhsupplier_MasterObjectDao.findByName1(keyword);

		    if (matchingObjects.isEmpty()) {
		        return null;
		    }

		    KKHSupplier_MasterObject obj = matchingObjects.get(0);

	

		    if (obj != null) {
		        Set<KKHSupplier_Object> returnSupplierSet = new HashSet<>();

		        for (KKHSupplier_Object s : obj.getSupplier()) {
		            Set<KKHSupplierDocument> returnAttachmentSet = new HashSet<>();
		            String attachmentIds = s.getDocumentId();

		            if (attachmentIds != null && !attachmentIds.isEmpty()) {
		                String[] idArray = attachmentIds.split(",");
		                for (String id : idArray) {
		                    try {
		                        Long attachmentId = Long.parseLong(id.trim());
		                        KKHSupplierDocument attachment = kkhsupplierDocumentDao.findById(attachmentId).orElse(null);
		                        if (attachment != null) {
		                            returnAttachmentSet.add(attachment);
		                        }
		                    } catch (NumberFormatException e) {
		                       
		                        e.printStackTrace();
		                    }
		                }
		            }

		            s.setDocument(returnAttachmentSet);
		            if (s.getIslatest_Iteration() == 1) {
		                returnSupplierSet.add(s);
		            }
		        }

		        obj.setSupplier(returnSupplierSet);
		    }

		    return obj;
		}
	

}
