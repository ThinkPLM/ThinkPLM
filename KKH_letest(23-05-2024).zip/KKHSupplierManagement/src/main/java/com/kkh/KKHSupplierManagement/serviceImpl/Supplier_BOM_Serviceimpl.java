package com.kkh.KKHSupplierManagement.serviceImpl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kkh.KKHSupplierManagement.Dao.PartUsageLinkDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_BOMDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_MasterPartObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_PartObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_PartsDao;
import com.kkh.KKHSupplierManagement.resource.KKHPartBomDetails;
import com.kkh.KKHSupplierManagement.resource.KKHPartData;
import com.kkh.KKHSupplierManagement.resource.KKHPartStructureResponse;
import com.kkh.KKHSupplierManagement.resource.PartUsageLink;
import com.kkh.KKHSupplierManagement.resource.Supplier_BOM;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_PartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_Parts;
import com.kkh.KKHSupplierManagement.service.Supplier_BOM_Service;

import jakarta.transaction.Transactional;

@Service
public class Supplier_BOM_Serviceimpl  implements Supplier_BOM_Service {

	@Autowired
	private Supplier_BOMDao supplier_bomDao;
	
	@Autowired
	private PartUsageLinkDao partUsageLinkDao;
	
	@Autowired
	private Supplier_PartObjectDao supplier_PartObjectDao;
	
	@Autowired
	private Supplier_Parts_Serviceimpl supplier_Parts_Serviceimpl;

	public static List<KKHPartData> childPartDataList = new ArrayList<KKHPartData>();
	public static List<Long> childPartDataIdList = new ArrayList<Long>();
	public static int repliesCounter = 0;
	
	@Override
	public Supplier_BOM addSupplier_BOM(Supplier_BOM supplier_bom) {

		supplier_bomDao.save(supplier_bom);
		return supplier_bom;
	}

	@Override
	public List<Supplier_BOM> getSupplier_BOM() {

		return this.supplier_bomDao.findAll();
	}

	@Override
	public Supplier_BOM getSupplier_BOMbyid(Long part_number) {

		return supplier_bomDao.getReferenceById(part_number);
	}

	@Override
	public Supplier_BOM updateSupplier_BOM(Supplier_BOM supplier_bom) {
		supplier_bomDao.save(supplier_bom);
		return supplier_bom;
	}

	@Override
	public HttpStatus deleteSupplier_BOM(Long parseLong) {
		if(supplier_bomDao.existsById(parseLong)) {
			Supplier_BOM supplier_bom = supplier_bomDao.getReferenceById(parseLong);
			supplier_bomDao.delete(supplier_bom);
			return HttpStatus.OK;
		}else {
			return HttpStatus.NOT_FOUND;
		}
	}

	@Override
	public KKHPartStructureResponse getPartStructureById(Long id) {
		// TODO Auto-generated method stub
		
		childPartDataList = new ArrayList<KKHPartData>();
		repliesCounter = 0;
		childPartDataIdList = new ArrayList<Long>();
		
		List<KKHPartBomDetails> detailList = new ArrayList<KKHPartBomDetails>();
		System.out.println("getPartStructureById:" );
		Supplier_PartObject inputParentPart = supplier_PartObjectDao.getReferenceById(id);
		Supplier_MasterPartObject childMaster = supplier_Parts_Serviceimpl.getSupplierMasterPartObjectsById(inputParentPart.getMasterId());
		System.out.println("childMaster:" + childMaster);
		
		KKHPartData parentPartData = populateKKHPartData(childMaster);
		childPartDataList.add(parentPartData);
		childPartDataIdList.add(parentPartData.getId());
		getChildParts(id);
		System.out.println("childPartDataList:" + childPartDataList);
		
		for(int i=0;i<childPartDataList.size();i++) {
			KKHPartBomDetails details = generateReplies(childPartDataList.get(i),childPartDataList);
			detailList.add(details);
		}
		
		KKHPartStructureResponse response = new KKHPartStructureResponse();
		response.setTopLevelParentId(id);
		response.setPartBomDetailsList(detailList);
		System.out.println("response:" + response);
		return response;
	}

	private KKHPartData populateKKHPartData(Supplier_MasterPartObject childMaster) {
		// TODO Auto-generated method stub
		System.out.println("Object number - " + childMaster.getPart_number());
		KKHPartData partData = new KKHPartData();
		partData.setParentId(Long.valueOf(0));
		partData.setPart_name(childMaster.getPart_name());
		partData.setPart_number(childMaster.getPart_number());
		partData.setDescription(childMaster.getDescription());
		Set<Supplier_PartObject> parts = childMaster.getParts();
		for(Supplier_PartObject part: parts) {
			partData.setId(part.getId());
			partData.setCompliance_information(part.getCompliance_information());
			partData.setCost(part.getCost());
			partData.setDimension(part.getDimension());
			partData.setIteration_info(part.getIteration_info());
			//
			partData.setSupplier_name(part.getSupplier_name());
			partData.setMaterial(part.getMaterial());
			partData.setMpn_number(part.getMpn_number());
			partData.setWeight(part.getWeight());
			partData.setLead_date(part.getLead_date());
			partData.setQuality_matrices(part.getQuality_matrices());
			partData.setModifiedDate(part.getModifiedDate());
			partData.setQuality_matrices(part.getQuality_matrices());
			partData.setCreatedDate(part.getCreatedDate());



		}
		return partData;
	}

	private KKHPartBomDetails generateReplies(KKHPartData data, List<KKHPartData> childPartList) {
		// TODO Auto-generated method stub
		List<Integer> replies = new ArrayList<Integer>();
		//childPartList.sort(Comparator.comparing(KKHPartData::getId));
		KKHPartBomDetails details = new KKHPartBomDetails();
		details.setData(data);
		Map<Long,List<KKHPartData>> groupedMap = childPartList.stream()
				.collect(Collectors.groupingBy(KKHPartData::getParentId));
		System.out.println("groupedMap:" + groupedMap);
		Long id = data.getId();
		System.out.println("id:" + id);
		if(groupedMap.containsKey(id)) {
			List<KKHPartData> tempList = groupedMap.get(id);
			for(int j=0;j<tempList.size();j++) {
				//replies.add(++repliesCounter);
				replies.add(childPartDataIdList.indexOf(tempList.get(j).getId()));
			}
		}
		details.setReplies(replies);
		return details;
	}

	private List<KKHPartData> getChildParts(Long id) {
		// TODO Auto-generated method stub
		System.out.println("getChildParts:" );
		List<PartUsageLink> usageLinkList = partUsageLinkDao.findByParentId(id);
		System.out.println("usageLinkList:" + usageLinkList);
		List<KKHPartData> temp = processObjectUsageLinks(usageLinkList);
		childPartDataList.addAll(temp);
		System.out.println("temp:" +temp );
		for(KKHPartData partD:temp) {
			System.out.println("in Child Loop:" );
			getChildParts(partD.getId());
		}
		return childPartDataList;
	}

	private List<KKHPartData> processObjectUsageLinks(List<PartUsageLink> usageLinkList) {
		// TODO Auto-generated method stub
		List<KKHPartData> partDataList = new ArrayList<KKHPartData>();
		for(PartUsageLink link : usageLinkList) {
			Supplier_MasterPartObject childMaster = supplier_Parts_Serviceimpl.getSupplierMasterPartObjectsById(link.getIda3b5());
			System.out.println("childMaster:" + childMaster.getPart_number());
			KKHPartData partData = new KKHPartData();
			partData.setParentId(link.getIda3a5());
			partData.setPart_name(childMaster.getPart_name());
			partData.setPart_number(childMaster.getPart_number());
			partData.setDescription(childMaster.getDescription());
			Set<Supplier_PartObject> parts = childMaster.getParts();
			for(Supplier_PartObject part: parts) {
				partData.setId(part.getId());
				partData.setCompliance_information(part.getCompliance_information());
				partData.setCost(part.getCost());
				partData.setDimension(part.getDimension());
				partData.setIteration_info(part.getIteration_info());
				//
				partData.setSupplier_name(part.getSupplier_name());
				partData.setMaterial(part.getMaterial());
				partData.setMpn_number(part.getMpn_number());
				partData.setWeight(part.getWeight());
				partData.setLead_date(part.getLead_date());
				partData.setQuality_matrices(part.getQuality_matrices());
				partData.setModifiedDate(part.getModifiedDate());
				partData.setQuality_matrices(part.getQuality_matrices());
				partData.setCreatedDate(part.getCreatedDate());
			}
			partDataList.add(partData);
			childPartDataIdList.add(partData.getId());
		}
		return partDataList;
	}

	@Override
	public PartUsageLink createUsageLink(PartUsageLink usageLink) {
		// TODO Auto-generated method stub
		PartUsageLink createdLink = partUsageLinkDao.save(usageLink);
		return createdLink;
	}

	@Override
    @Transactional
	 public void deleteByIda3a5AndIda3b5(Long ida3a5, Long ida3b5) {
		 partUsageLinkDao.deleteByIda3a5AndIda3b5(ida3a5, ida3b5);
	    }
	
}
