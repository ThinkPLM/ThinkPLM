package com.kkh.KKHSupplierManagement.serviceImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.kkh.KKHSupplierManagement.Dao.AttachmentDao;
import com.kkh.KKHSupplierManagement.Dao.KKHSupplierDocumentDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_Contract1Dao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_ContractDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_ContractObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_MasterContractDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_MasterContractObjectDao;
import com.kkh.KKHSupplierManagement.resource.Attachment;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.KKHSupplierDocument;
import com.kkh.KKHSupplierManagement.resource.SupplierContractRequestBean;
import com.kkh.KKHSupplierManagement.resource.SupplierPartRequestBean;
import com.kkh.KKHSupplierManagement.resource.Supplier_Contract;
import com.kkh.KKHSupplierManagement.resource.Supplier_Contract1;
import com.kkh.KKHSupplierManagement.resource.Supplier_ContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterContract;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPart;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_PartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_Parts;
import com.kkh.KKHSupplierManagement.service.Supplier_Contract_Service;

@Service
public class Supplier_Contract_Serviceimpl implements Supplier_Contract_Service {
	@Autowired
	private AttachmentDao attachmentDao;
	@Autowired
	Supplier_Contract1Dao supplier_Contract1Dao;
	@Autowired
	private Supplier_MasterContractDao supplier_MasterContractDao;
	@Autowired
	private Supplier_ContractDao supplier_contractDao;

	@Autowired
	private Supplier_ContractObjectDao supplier_ContractObjectDao;

	@Autowired
	private Supplier_MasterContractObjectDao supplier_MasterContractObjectDao;

	@Autowired
	private KKHSupplierDocumentDao kkhsupplierDocumentDao;

//	private String pricing_payment;
//	private String term_termination;
//	private String law_and_Jursidication;
//	private String signatures;
	@Override
	public Supplier_Contract addSupplier_Contract(Supplier_Contract supplier_contract) {
		String pricing_payment = supplier_contract.getPricing_payment();
		String term_termination = supplier_contract.getTerm_termination();
		String law_and_Jursidication = supplier_contract.getLaw_and_Jursidication();
		String signatures = supplier_contract.getSignatures();

		KKHSupplierDocument supplier_contract_document = new KKHSupplierDocument();
		supplier_contract_document.setFileType("supplier_contract_doc");
		supplier_contract_document.setDocument(pricing_payment);
		supplier_contract_document.setDocument(term_termination);
		supplier_contract_document.setDocument(law_and_Jursidication);
		supplier_contract_document.setDocument(signatures);

		KKHSupplierDocument savedoc = kkhsupplierDocumentDao.save(supplier_contract_document);

		supplier_contract.setPricing_payment(savedoc.getId().toString());
		supplier_contract.setTerm_termination(savedoc.getId().toString());
		supplier_contract.setLaw_and_Jursidication(savedoc.getId().toString());
		supplier_contract.setSignatures(savedoc.getId().toString());

		supplier_contractDao.save(supplier_contract);
		return supplier_contract;
	}

	@Override
	public List<Supplier_Contract> getSupplier_contracts() {
		return this.supplier_contractDao.findAll();
	}

	@Override
	public Supplier_Contract getSupplier_Contract(Long document_number) {

		return supplier_contractDao.getReferenceById(document_number);
	}

	@Override
	public Supplier_Contract updateSupplier_Contract(Supplier_Contract supplier_contract) {
		supplier_contractDao.save(supplier_contract);
		return supplier_contract;
	}

	@Override
	public HttpStatus deleteSupplier_Contract(Long parseLong) {
		if (supplier_contractDao.existsById(parseLong)) {
			Supplier_Contract supplier_contract = supplier_contractDao.getReferenceById(parseLong);
			supplier_contractDao.delete(supplier_contract);
			return HttpStatus.OK;
		} else {
			return HttpStatus.NOT_FOUND;
		}

	}

	// History

	@Override
	public SupplierContractRequestBean createSupplier_Contract(SupplierContractRequestBean contractRequestBean) {

		Supplier_MasterContract masterContract = contractRequestBean.getSupplier_MasterContract();
		System.out.println("masterContract:" + masterContract);
		Supplier_Contract1 contract = contractRequestBean.getSupplier_Contract1();
		System.out.println("contract:" + contract);
		Supplier_MasterContract savedMasterContract = supplier_MasterContractDao.save(masterContract);

		contract.setMasterId(savedMasterContract.getId());
		Supplier_Contract1 savedContract = supplier_Contract1Dao.save(contract);

		SupplierContractRequestBean savedContractBean = new SupplierContractRequestBean(savedMasterContract.getId(),
				savedMasterContract, savedContract);

		return savedContractBean;
	}

	@Override
	public ArrayList<SupplierContractRequestBean> getSupplierMasterContract() {

		List<Supplier_MasterContract> masterContractList = supplier_MasterContractDao.findAll();
		List<Supplier_Contract1> contractList = supplier_Contract1Dao.findAll();

		System.out.println("masterContractList:" + masterContractList);
		System.out.println("contractList:" + contractList);
		ArrayList<SupplierContractRequestBean> returnBeanList = new ArrayList<>();
		for (Supplier_MasterContract master : masterContractList) {
			SupplierContractRequestBean bean = new SupplierContractRequestBean();
			Supplier_Contract1 beanContract = new Supplier_Contract1();
			bean.setId(master.getId());
			bean.setSupplier_MasterContract(master);
			for (Supplier_Contract1 contract : contractList) {
				if (contract.getMasterId() == master.getId()) {
					beanContract = contract;
				}
			}
			bean.setSupplier_Contract1(beanContract);
			returnBeanList.add(bean);
		}

		return returnBeanList;
	}
	@Override
	public Supplier_MasterContractObject getSupplierMasterContractObjectsById(Long masterId) {
	    Supplier_MasterContractObject obj = supplier_MasterContractObjectDao.findById(masterId).orElse(null);

	    if (obj != null) {
	        Set<Supplier_ContractObject> returnContractSet = new HashSet<>();

	        for (Supplier_ContractObject s : obj.getSupplier_contract()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                        // Handle invalid attachment ID format
	                        // Log or handle the exception as appropriate
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setAttachment(returnAttachmentSet);

	            if (s.getIslatest_Iteration() == 1) {
	                returnContractSet.add(s);
	            }
	        }

	        obj.setSupplier_contract(returnContractSet);
	    }

	    return obj;
	}



	@Override
	public Supplier_MasterContractObject createSupplier_ContractObject(
			Supplier_MasterContractObject masterContractObject) {

		    if (supplier_MasterContractObjectDao.existsByDocumentNumber(masterContractObject.getDocument_number())) {
		       
		        throw new IllegalArgumentException("document number already exists in Supplier_MasterContractObject.");
		    }

		    if (supplier_MasterContractObjectDao.existsByDocumentName(masterContractObject.getDocument_name())) {
		   
		    	throw new IllegalArgumentException("document name already exists in Supplier_MasterContractObject.");
		    }

		    masterContractObject.setDocumenttype("Supplier Contract");

		    Supplier_MasterContractObject savedObj = supplier_MasterContractObjectDao.save(masterContractObject);

		    Set<Supplier_ContractObject> supplierContractObjectSet = masterContractObject.getSupplier_contract();

		    for (Supplier_ContractObject sObject : supplierContractObjectSet) {
		        Set<Attachment> attachmentSet = sObject.getAttachment();
		        List<Attachment> savedAttachmentSet = attachmentDao.saveAll(attachmentSet);
		        String attachedId = "";

		        for (Attachment atc : savedAttachmentSet) {
		            if (attachedId.isEmpty()) {
		                attachedId = String.valueOf(atc.getId());
		            } else {
		                attachedId += "," + atc.getId();
		            }
		        }

		        sObject.setAttachmentId(attachedId);
		        sObject.setMasterId(savedObj.getId());
		    }

		    supplier_ContractObjectDao.saveAll(supplierContractObjectSet);
		    return savedObj;
		}

	@Override
	public List<Supplier_MasterContractObject> getSupplierMasterContractObjects() {

	    List<Supplier_MasterContractObject> obj = supplier_MasterContractObjectDao.findAll();

	    for (Supplier_MasterContractObject master : obj) {
	        Set<Supplier_ContractObject> returnContractSet = new HashSet<>();

	        for (Supplier_ContractObject s : master.getSupplier_contract()) {
	            Set<Attachment> returnAttachmentSet = new HashSet<>();
	            String attachmentIds = s.getAttachmentId();

	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] idArray = attachmentIds.split(",");
	                for (String id : idArray) {
	                    try {
	                        Long attachmentId = Long.parseLong(id.trim());
	                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
	                        if (attachment != null) {
	                            returnAttachmentSet.add(attachment);
	                        }
	                    } catch (NumberFormatException e) {
	                        
	                        e.printStackTrace();
	                    }
	                }
	            }

	            s.setAttachment(returnAttachmentSet);

	            if (s.getIslatest_Iteration() == 1) {
	                returnContractSet.add(s);
	            }
	        }
	        master.setSupplier_contract(returnContractSet);
	    }

	    return obj;
	}
	@Override
	public Supplier_MasterContractObject updateSupplier_ContractObject(Supplier_MasterContractObject masterContractObject) {
	    try {

	    	Supplier_MasterContractObject existingMasterContractObject = supplier_MasterContractObjectDao
	                .getReferenceById(masterContractObject.getId());

	        if (existingMasterContractObject == null) {

	        	throw new IllegalArgumentException("Master contract object does not exist with id: " + masterContractObject.getId());
	        }


	        Set<Supplier_ContractObject> existingContractObjects = existingMasterContractObject.getSupplier_contract();
	        for (Supplier_ContractObject contractObject : existingContractObjects) {
	            contractObject.setIslatest_Iteration(0);
	            supplier_ContractObjectDao.save(contractObject);
	        }


	        Set<Supplier_ContractObject> updatedContractObjects = masterContractObject.getSupplier_contract();
	        List<Supplier_ContractObject> savedContractObjects = new ArrayList<>();
	        for (Supplier_ContractObject updatedContractObject : updatedContractObjects) {

	        	updatedContractObject.setId(null);
	            updatedContractObject.setMasterId(masterContractObject.getId());
	            updatedContractObject.setIslatest_Iteration(1);
	            updatedContractObject.setIteration_info(updatedContractObject.getIteration_info() + 1);


	            Set<Attachment> attachmentSet = updatedContractObject.getAttachment();
	            Set<Attachment> savedAttachmentSet = new HashSet<>();
	            for (Attachment attachment : attachmentSet) {

	            	if (attachment.getAttachmentType() == null) {
	                    attachment.setAttachmentType("DEFAULT_ATTACHMENT_TYPE"); // Set a default attachment type

	                }
	                Attachment savedAttachment = attachmentDao.save(attachment);
	                savedAttachmentSet.add(savedAttachment);
	            }
	            updatedContractObject.setAttachment(savedAttachmentSet);


	            Supplier_ContractObject savedContractObject = supplier_ContractObjectDao.save(updatedContractObject);
	            savedContractObjects.add(savedContractObject);
	        }


	        existingMasterContractObject.setSupplier_contract(new HashSet<>(savedContractObjects));

	        Supplier_MasterContractObject returnMasterObj = supplier_MasterContractObjectDao.save(existingMasterContractObject);
	        return returnMasterObj;
	    } catch (Exception e) {

	    	e.printStackTrace(); 
	        throw new RuntimeException("Failed to update supplier contract object: " + e.getMessage());
	    }
	}



	
	@Override
	public Supplier_MasterContractObject getSupplierMasterContractObjectsHistoryById(Long masterId) {
	    Supplier_MasterContractObject obj = supplier_MasterContractObjectDao.getReferenceById(masterId);

	    Set<Supplier_ContractObject> contractObjects = obj.getSupplier_contract();

	    for (Supplier_ContractObject contractObject : contractObjects) {
	        String attachmentIds = contractObject.getAttachmentId();
	        if (attachmentIds != null && !attachmentIds.isEmpty()) {
	            String[] attachmentIdArray = attachmentIds.split(",");
	            Set<Attachment> attachments = new HashSet<>();
	            for (String attachmentId : attachmentIdArray) {
	                Long id = Long.parseLong(attachmentId.trim());
	                Attachment attachment = attachmentDao.getById(id);
	                if (attachment != null) {
	                    attachments.add(attachment);
	                }
	            }
	            contractObject.setAttachment(attachments);
	        }
	    }

	    obj.setSupplier_contract(contractObjects);

	    return obj;
	}

	@Override
	public HttpStatus deleteSupplierMasterContractObject(Long parseLong) {
	    if (supplier_MasterContractObjectDao.existsById(parseLong)) {

	    	Supplier_MasterContractObject obj = supplier_MasterContractObjectDao.getReferenceById(parseLong);
	        
	        Set<Supplier_ContractObject> contractObjects = obj.getSupplier_contract();
	        
	        for (Supplier_ContractObject contractObject : contractObjects) {

	        	String attachmentIds = contractObject.getAttachmentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");

	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    Attachment attachment = attachmentDao.getById(id);
	                    if (attachment != null) {
	                        attachmentDao.delete(attachment);
	                    }
	                }
	            }
	            supplier_ContractObjectDao.delete(contractObject);
	        }
	        
	        supplier_MasterContractObjectDao.delete(obj);
	        
	        return HttpStatus.OK;
	    } else {
	        return HttpStatus.NOT_FOUND;
	    }
	}




	@Override
	public HttpStatus deleteSupplierContractObjectsHistoryById(Long parseLong) {

		if (supplier_ContractObjectDao.existsById(parseLong)) {
			Supplier_ContractObject obj1 = supplier_ContractObjectDao.getReferenceById(parseLong);
			supplier_ContractObjectDao.delete(obj1);

			return HttpStatus.OK;
		} else {
			return HttpStatus.NOT_FOUND;
		}
	}



	@Override
	public List<Supplier_MasterContractObject> getSupplier_MasterContractObjectBydocument_number(String document_number) {
	    List<Supplier_MasterContractObject> masterContractObjects = supplier_MasterContractObjectDao.findByDocument_number(document_number);
	    
	    for (Supplier_MasterContractObject obj : masterContractObjects) {
	        Set<Supplier_ContractObject> contractObjects = obj.getSupplier_contract();
	        
	        for (Supplier_ContractObject contractObject : contractObjects) {
	            String attachmentIds = contractObject.getAttachmentId();
	            if (attachmentIds != null && !attachmentIds.isEmpty()) {
	                String[] attachmentIdArray = attachmentIds.split(",");
	                Set<Attachment> attachments = new HashSet<>();
	                for (String attachmentId : attachmentIdArray) {
	                    Long id = Long.parseLong(attachmentId.trim());
	                    Attachment attachment = attachmentDao.getById(id);
	                    if (attachment != null) {
	                        attachments.add(attachment);
	                    }
	                }
	                contractObject.setAttachment(attachments);
	            }
	        }
	        
	        obj.setSupplier_contract(contractObjects);
	    }
	    
	    return masterContractObjects;
	}

	@Override
	public Supplier_MasterContractObject getSupplier_MasterContractObjectByKeyword(String keyword) {

	    List<Supplier_MasterContractObject> matchingObjects = supplier_MasterContractObjectDao.findByDocumentNumberOrDocumentName(keyword);

	    if (matchingObjects.isEmpty()) {
	        return null;
	    }

	    Supplier_MasterContractObject obj = matchingObjects.get(0);
		    if (obj != null) {
		        Set<Supplier_ContractObject> returnContractSet = new HashSet<>();

		        for (Supplier_ContractObject s : obj.getSupplier_contract()) {
		            Set<Attachment> returnAttachmentSet = new HashSet<>();
		            String attachmentIds = s.getAttachmentId();

		            if (attachmentIds != null && !attachmentIds.isEmpty()) {
		                String[] idArray = attachmentIds.split(",");
		                for (String id : idArray) {
		                    try {
		                        Long attachmentId = Long.parseLong(id.trim());
		                        Attachment attachment = attachmentDao.findById(attachmentId).orElse(null);
		                        if (attachment != null) {
		                            returnAttachmentSet.add(attachment);
		                        }
		                    } catch (NumberFormatException e) {
		                        // Handle invalid attachment ID format
		                        // Log or handle the exception as appropriate
		                        e.printStackTrace();
		                    }
		                }
		            }

		            s.setAttachment(returnAttachmentSet);

		            if (s.getIslatest_Iteration() == 1) {
		                returnContractSet.add(s);
		            }
		        }

		        obj.setSupplier_contract(returnContractSet);
		    }

		    return obj;
		}

}
