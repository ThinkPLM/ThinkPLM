package com.kkh.KKHSupplierManagement.webservices;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Certification_of_insuranceRequestBean;
import com.kkh.KKHSupplierManagement.resource.Invoice;
import com.kkh.KKHSupplierManagement.resource.SupplierPartRequestBean;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;
import com.kkh.KKHSupplierManagement.service.Certification_of_Insurance_Service;
import com.kkh.KKHSupplierManagement.service.Invoice_Service;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class Certification_of_InsuranceRestController {

	@Autowired
	private Certification_of_Insurance_Service certification_of_insurance_service;

	// add get Invoices
	@PostMapping(path = "/addCertification_of_Insurance")
	public ResponseEntity<Void> addCertification_of_Insurance(
			@RequestBody Certification_of_Insurance certification_of_insurance) {

		Certification_of_Insurance Certification_of_Insurance1 = this.certification_of_insurance_service
				.addCertification_of_Insurance(certification_of_insurance);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{policy_number}")
				.buildAndExpand(Certification_of_Insurance1.getPolicy_number()).toUri();

		return ResponseEntity.created(uri).build();
	}

	// get get Certification_of_Insurances
	@GetMapping("/getCertification_of_Insurance")
	public List<Certification_of_Insurance> getCertification_of_Insurances() {

		return this.certification_of_insurance_service.getCertification_of_Insurances();
	}

//	  	single Certification_of_Insurance get
	@GetMapping("/getIdCertification_of_Insurance/{policy_number}")
	public @ResponseBody Certification_of_Insurance getCertification_of_Insurance(
			@PathVariable("policy_number") Long policy_number) {

		return this.certification_of_insurance_service.getCertification_of_Insurance(policy_number);

	}

//update Certification_of_Insurance using PUT request
	@PutMapping("/updateCertification_of_Insurance")
	public Certification_of_Insurance updateCertification_of_Insurance(
			@RequestBody Certification_of_Insurance certification_of_insurance) {

		return this.certification_of_insurance_service.updateCertification_of_Insurance(certification_of_insurance);
	}

	// delete the Certification_of_Insurance
	@DeleteMapping("/deleteCertification_of_Insurance/{policy_number}")
	public ResponseEntity<HttpStatus> deleteCertification_of_Insurance(
			@PathVariable("policy_number") String policy_number) {

		HttpStatus status4 = this.certification_of_insurance_service
				.deleteCertification_of_Insurance(Long.parseLong(policy_number));
		return new ResponseEntity<>(status4);

	}
	
	
	//History maintain code
	
	@PostMapping(path = "/CreateCertification_of_Insurance")
	public ResponseEntity<Void> createCertification_of_insurance(@RequestBody Certification_of_insuranceRequestBean certificationRequestBean) {

		
		Certification_of_insuranceRequestBean CertificationRequestBean = this.certification_of_insurance_service.createCertification_of_insurance(certificationRequestBean);
		
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(CertificationRequestBean .getId()).toUri();

		return ResponseEntity.created(uri).build();
	}

	
	@GetMapping(path = "/getCertification_of_InsuranceMaster")
	public ArrayList<Certification_of_insuranceRequestBean> getCertification_of_insurance() {

		
		ArrayList<Certification_of_insuranceRequestBean> certification_of_insuranceRequestBeanList = this.certification_of_insurance_service.getCertification_of_insurance();
		
		return certification_of_insuranceRequestBeanList;
	}
	
	
	@GetMapping(path = "/Certification_of_InsuranceMasterObject1/{masterId}")
	public Certification_of_Insurance_Master_Object getCertification_of_Insurance_Master_ObjectById(@PathVariable("masterId") Long masterId) {
		
		Certification_of_Insurance_Master_Object supMasterCertificationObject = this.certification_of_insurance_service.getCertification_of_Insurance_Master_ObjectById(masterId);
		return supMasterCertificationObject;
	}
	


	@PostMapping(path = "/Certification_of_InsuranceMasterObject")
	public ResponseEntity<Void> createCertification_of_Insurance_Object(@RequestBody Certification_of_Insurance_Master_Object masterCertificationObject) {

		
		Certification_of_Insurance_Master_Object certification_of_Insurance_Master_Object = this.certification_of_insurance_service.createCertification_of_Insurance_Object(masterCertificationObject);
		
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(certification_of_Insurance_Master_Object.getId()).toUri();

	 	return ResponseEntity.created(uri).build();
	}
	
	@GetMapping(path = "/Certification_of_InsuranceMasterObject")
	public List<Certification_of_Insurance_Master_Object> getCertification_of_Insurance_Master_Object() {
		
		List<Certification_of_Insurance_Master_Object> supCertificationObjectList = this.certification_of_insurance_service.getCertification_of_Insurance_Master_Object();
		return supCertificationObjectList;
	}
	
	
	

	@PutMapping(path = "/Certification_of_InsuranceMasterObject")
	public ResponseEntity<Void> updateCertification_of_Insurance_Object(@RequestBody Certification_of_Insurance_Master_Object masterCertificationObject) {

		
		Certification_of_Insurance_Master_Object certification_of_Insurance_Master_Object = this.certification_of_insurance_service.updateCertification_of_Insurance_Object(masterCertificationObject);
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(certification_of_Insurance_Master_Object.getId()).toUri();

		return ResponseEntity.created(uri).build();
	}
	
	@GetMapping(path = "/Certification_of_InsuranceMasterObject/{masterId}")
	public Certification_of_Insurance_Master_Object getCertificationInsuranceMasterObjectsHistoryById(@PathVariable("masterId") Long masterId) {
		
		Certification_of_Insurance_Master_Object supMasterPartObject = this.certification_of_insurance_service.getCertificationInsuranceMasterObjectsHistoryById(masterId);
		return supMasterPartObject;
	}
	
	
	@DeleteMapping("/Certification_of_InsuranceMasterObject/{masterId}")
	public ResponseEntity<HttpStatus> deleteCertificationInsuranceMasterObject(@PathVariable("masterId") String masterId) {

		HttpStatus status = this.certification_of_insurance_service.deleteCertificationInsuranceMasterObject(Long.parseLong(masterId));
		return new ResponseEntity<>(status);

	}
	
	
	@DeleteMapping("/Certification_of_InsuranceObject/{id}")
	public ResponseEntity<HttpStatus> deleteCertificationInsuranceObjectHistoryById(@PathVariable("id") String id) {

		HttpStatus status = this.certification_of_insurance_service.deleteCertificationInsuranceObjectHistoryById(Long.parseLong(id));
		return new ResponseEntity<>(status);

	}
	
	@GetMapping(path = "/Certification_of_InsuranceMasterObjectBydocument_number/{document_number}")
	public @ResponseBody List<Certification_of_Insurance_Master_Object> getCertification_of_Insurance_Master_ObjectBydocument_number(@PathVariable("document_number") String document_number) {
		
		return this.certification_of_insurance_service.getCertification_of_Insurance_Master_ObjectBydocument_number(document_number);

	}
	
}
