package com.kkh.KKHSupplierManagement.webservices;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Certification_of_insuranceRequestBean;
import com.kkh.KKHSupplierManagement.resource.ComplainceCertificateRequestBean;
import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_MasterObject;
import com.kkh.KKHSupplierManagement.resource.Compliance_Certification;
import com.kkh.KKHSupplierManagement.resource.Invoice;
import com.kkh.KKHSupplierManagement.service.Compliance_Certification_Service;
import com.kkh.KKHSupplierManagement.service.Invoice_Service;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class Compliance_CertificationRestController {

	@Autowired
	private Compliance_Certification_Service compliance_certification_service;

	// add get Invoices
	@PostMapping(path = "/addCompliance_Certification")
	public ResponseEntity<Void> addCompliance_Certification(
			@RequestBody Compliance_Certification compliance_certification) {

		Compliance_Certification compliance_certification1 = this.compliance_certification_service
				.addCompliance_Certification(compliance_certification);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{certification_number}")
				.buildAndExpand(compliance_certification1.getCertification_number()).toUri();

		return ResponseEntity.created(uri).build();
	}

	// get get Compliance_Certification
	@GetMapping("/getCompliance_Certification")
	public List<Compliance_Certification> getCompliance_Certifications() {

		return this.compliance_certification_service.getCompliance_Certifications();
	}

//	  	single Compliance_Certification get
	@GetMapping("/getIdCompliance_Certification/{certification_number}")
	public @ResponseBody Compliance_Certification getCompliance_Certification(
			@PathVariable("certification_number") Long certification_number) {

		return this.compliance_certification_service.getCompliance_Certification(certification_number);

	}

//update Compliance_Certification using PUT request
	@PutMapping("/updateCompliance_Certification")
	public Compliance_Certification updateCompliance_Certification(
			@RequestBody Compliance_Certification compliance_certification) {

		return this.compliance_certification_service.updateCompliance_Certification(compliance_certification);
	}

	// delete the Compliance_Certification
	@DeleteMapping("/deleteCompliance_Certification/{certification_number}")
	public ResponseEntity<HttpStatus> deleteInvoice(@PathVariable("certification_number") String certification_number) {

		HttpStatus status5 = this.compliance_certification_service
				.deleteCompliance_Certification(Long.parseLong(certification_number));
		return new ResponseEntity<>(status5);

	}

	

	//History maintain code
	
	@PostMapping(path = "/CreateComplainceCertificate")
	public ResponseEntity<Void> createComplianceCertificate(@RequestBody ComplainceCertificateRequestBean complainceCertificateRequestBean) {

		
		ComplainceCertificateRequestBean complainceCertificateRequestBean1 = this.compliance_certification_service.createComplianceCertificate(complainceCertificateRequestBean);
		
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(complainceCertificateRequestBean1 .getId()).toUri();

		return ResponseEntity.created(uri).build();
	}

	
	@GetMapping(path = "/getComplainceCertificateMaster")
	public ArrayList<ComplainceCertificateRequestBean> getMasterComplainceCertificate() {

		
		ArrayList<ComplainceCertificateRequestBean> complainceCertificateRequestBean1 = this.compliance_certification_service.getMasterComplainceCertificate();
		
		return complainceCertificateRequestBean1;
	}
	
	
	@GetMapping(path = "/ComplainceCertificateMasterObject1/{masterId}")
	public Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObjectById(@PathVariable("masterId") Long masterId) {
		
		Complaince_Certificate_MasterObject complaince_Certificate_MasterObject1 = this.compliance_certification_service.getComplaince_Certificate_MasterObjectById(masterId);
		return complaince_Certificate_MasterObject1;
	}
	


	@PostMapping(path = "/ComplainceCertificateMasterObject")
	public ResponseEntity<Void> createComplaince_Certificate_MasterObject(@RequestBody Complaince_Certificate_MasterObject masterComplaince_CertificateObject) {

		
		Complaince_Certificate_MasterObject complaince_Certificate_MasterObject1 = this.compliance_certification_service.createComplaince_Certificate_MasterObject(masterComplaince_CertificateObject);
		
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(complaince_Certificate_MasterObject1.getId()).toUri();

	 	return ResponseEntity.created(uri).build();
	}
	
	@GetMapping(path = "/ComplainceCertificateMasterObject")
	public List<Complaince_Certificate_MasterObject> getComplaince_Certificate_MasterObject() {
		
		List<Complaince_Certificate_MasterObject> complaince_Certificate_MasterObject1 = this.compliance_certification_service.getComplaince_Certificate_MasterObject();
		return complaince_Certificate_MasterObject1;
	}
	
	
	

	@PutMapping(path = "/ComplainceCertificateMasterObject")
	public ResponseEntity<Void> updateComplaince_Certificate_MasterObject(@RequestBody Complaince_Certificate_MasterObject masterComplaince_CertificateObject) {

		
		Complaince_Certificate_MasterObject complaince_Certificate_MasterObject1 = this.compliance_certification_service.updateComplaince_Certificate_MasterObject(masterComplaince_CertificateObject);
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(complaince_Certificate_MasterObject1.getId()).toUri();

		return ResponseEntity.created(uri).build();
	}
	
	@GetMapping(path = "/ComplainceCertificateMasterObject/{masterId}")
	public Complaince_Certificate_MasterObject getComplaince_Certificate_MasterObjectHistoryById(@PathVariable("masterId") Long masterId) {
		
		Complaince_Certificate_MasterObject supMasterPartObject = this.compliance_certification_service.getComplaince_Certificate_MasterObjectHistoryById(masterId);
		return supMasterPartObject;
	}
	
	
	@DeleteMapping("/ComplainceCertificateMasterObject/{masterId}")
	public ResponseEntity<HttpStatus> deleteComplaince_Certificate_MasterObject(@PathVariable("masterId") String masterId) {

		HttpStatus status = this.compliance_certification_service.deleteComplaince_Certificate_MasterObject(Long.parseLong(masterId));
		return new ResponseEntity<>(status);

	}

	
	
	@DeleteMapping("/ComplainceCertificateObject/{id}")
	public ResponseEntity<HttpStatus> deleteComplaince_Certificate_ObjectHistoryById(@PathVariable("id") String id) {

		HttpStatus status = this.compliance_certification_service.deleteComplaince_Certificate_ObjectHistoryById(Long.parseLong(id));
		return new ResponseEntity<>(status);

	}
	
	@GetMapping(path = "/ComplainceCertificateMasterObjectBydocument_number/{document_number}")
	public @ResponseBody List<Complaince_Certificate_MasterObject> getComplaince_Certificate_MasterObjectBydocument_number(@PathVariable("document_number") String document_number) {
		
		return this.compliance_certification_service.getComplaince_Certificate_MasterObjectBydocument_number(document_number);

	}
	
	
}
