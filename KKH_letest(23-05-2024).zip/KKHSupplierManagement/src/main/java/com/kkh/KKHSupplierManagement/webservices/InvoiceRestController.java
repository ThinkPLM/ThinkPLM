package com.kkh.KKHSupplierManagement.webservices;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.kkh.KKHSupplierManagement.Dao.Invoice_Master_ObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Invoice_ObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_MasterPartObjectDao;
import com.kkh.KKHSupplierManagement.Dao.Supplier_PartObjectDao;
import com.kkh.KKHSupplierManagement.resource.Certification_of_Insurance_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Complaince_Certificate_MasterObject;
import com.kkh.KKHSupplierManagement.resource.Invoice;
import com.kkh.KKHSupplierManagement.resource.InvoiceRequestBean;
import com.kkh.KKHSupplierManagement.resource.Invoice_Master_Object;
import com.kkh.KKHSupplierManagement.resource.Invoice_Object;
import com.kkh.KKHSupplierManagement.resource.KKHSupplier_MasterObject;
import com.kkh.KKHSupplierManagement.resource.SupplierPartRequestBean;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_PartObject;
import com.kkh.KKHSupplierManagement.service.Certification_of_Insurance_Service;
import com.kkh.KKHSupplierManagement.service.Compliance_Certification_Service;
import com.kkh.KKHSupplierManagement.service.Invoice_Service;
import com.kkh.KKHSupplierManagement.service.KKHSupplierService;
import com.kkh.KKHSupplierManagement.service.Supplier_Contract_Service;


@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class InvoiceRestController {

	@Autowired
	private Invoice_Service invoice_service;
	@Autowired
	private	Invoice_Master_ObjectDao invoice_Master_ObjectDao;
	@Autowired
	private Supplier_MasterPartObjectDao supplier_MasterPartObjectDao;
	@Autowired
	private	Invoice_ObjectDao invoice_ObjectDao;
	@Autowired
	private Supplier_PartObjectDao supplier_PartObjectDao;
	@Autowired
	private Supplier_Contract_Service supplier_contract_service;
	@Autowired
	private Compliance_Certification_Service compliance_certification_service;
	@Autowired
	private Certification_of_Insurance_Service certification_of_insurance_service;
	@Autowired
	private KKHSupplierService kkhSupplierService;
	
	
	// add get Invoices
	@PostMapping(path = "/addInvoice")
	public ResponseEntity<Void> addInvoice(@RequestBody Invoice invoice) {

		Invoice invoice1 = this.invoice_service.addInvoice(invoice);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{invoice_number}")
				.buildAndExpand(invoice1.getInvoice_number()).toUri();

		return ResponseEntity.created(uri).build();
	}

	// get get Invoices
	@GetMapping("/getInvoice")
	public List<Invoice> getInvoices() {

		return this.invoice_service.getInvoices();
	}

//	  	single Invoice get
	@GetMapping("/getIdInvoice/{invoice_number}")
	public @ResponseBody Invoice getInvoice(@PathVariable("invoice_number") Long invoice_number) {

		return this.invoice_service.getInvoice(invoice_number);

	}

//update Invoice using PUT request
	@PutMapping("/updateInvoice")
	public Invoice updateInvoice(@RequestBody Invoice invoice) {

		return this.invoice_service.updateInvoice(invoice);
	}

	// delete the Invoice
	@DeleteMapping("/deleteInvoice/{invoice_number}")
	public ResponseEntity<HttpStatus> deleteInvoice(@PathVariable("invoice_number") String invoice_number) {

		HttpStatus status3 = this.invoice_service.deleteInvoice(Long.parseLong(invoice_number));
		return new ResponseEntity<>(status3);

	}

//	History
	
	
	@PostMapping(path = "/CreateInvoice")
	public ResponseEntity<Void> createInvoice(@RequestBody InvoiceRequestBean invoiceRequestBean) {

		
		InvoiceRequestBean invoiceRequestBean1 = this.invoice_service.createInvoice(invoiceRequestBean);
		
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(invoiceRequestBean1.getId()).toUri();

		return ResponseEntity.created(uri).build();
		
		
		
		
	}
	
	@GetMapping(path = "/getInvoiceMasterInvoices")
	public ArrayList<InvoiceRequestBean> getInvoiceMaster() {

		
		ArrayList<InvoiceRequestBean> invoiceRequestBeanList = this.invoice_service.getMasterInvoice();
		
		return invoiceRequestBeanList;
	}
	
	
	@GetMapping(path = "/InvoiceMasterObject1/{masterId}")
	public Invoice_Master_Object getInvoiceMasterObjectById(@PathVariable("masterId") Long masterId) {
		
		Invoice_Master_Object supMasterInvoicesObject = this.invoice_service.getInvoice_MasterObjectsById(masterId);
		return supMasterInvoicesObject;
	}
	
	
	
	
	@GetMapping(path = "/InvoiceMasterObject")
	public List<Invoice_Master_Object> getInvoiceMasterObject() {
		
		List<Invoice_Master_Object> supMasterInvoicesObjectList = this.invoice_service.getInvoiceMasterObject();
		return supMasterInvoicesObjectList;
	}
	
	@PostMapping(path = "/InvoiceMasterObject")
	public ResponseEntity<Void> createInvoice_Object(@RequestBody Invoice_Master_Object masterInvoicesObject) {

		
		Invoice_Master_Object invoice_Master_Object = this.invoice_service.createInvoice_Master_Object(masterInvoicesObject);
		
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(invoice_Master_Object.getId()).toUri();

	 	return ResponseEntity.created(uri).build();
	}
	
	@PutMapping(path = "/InvoiceMasterObject")
	public ResponseEntity<Void> updateInvoice_Object(@RequestBody Invoice_Master_Object masterInvoicesObject) {

		
		Invoice_Master_Object invoice_Master_Object = this.invoice_service.updateInvoiceObject(masterInvoicesObject);
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
				.buildAndExpand(invoice_Master_Object.getId()).toUri();

		return ResponseEntity.created(uri).build();
	}
	
	
	
	@GetMapping(path = "/InvoiceMasterObject/{masterId}")
	public Invoice_Master_Object getInvoice_Master_ObjectHistoryById(@PathVariable("masterId") Long masterId) {
		
		Invoice_Master_Object inMasterInvoicesObject = this.invoice_service.getInvoiceMasterObjectsHistoryById(masterId);
		return inMasterInvoicesObject;
	}
	
	
	@DeleteMapping("/InvoiceMasterObject/{masterId}")
	public ResponseEntity<HttpStatus> deleteInvoiceMasterObject(@PathVariable("masterId") String masterId) {

		HttpStatus status = this.invoice_service.deleteInvoiceMasterObject(Long.parseLong(masterId));
		return new ResponseEntity<>(status);

	}

	
	
	@DeleteMapping("/InvoiceObject/{id}")
	public ResponseEntity<HttpStatus> deleteInvoiceObjectHistoryById(@PathVariable("id") String id) {

		HttpStatus status = this.invoice_service.deleteInvoiceObjectsHistoryById(Long.parseLong(id));
		return new ResponseEntity<>(status);

	}
	
	@GetMapping(path = "/InvoiceObjectByinvoice_number/{invoice_number}")
	public @ResponseBody List<Invoice_Master_Object> getInvoice_MasterObjectByinvoice_number(@PathVariable("invoice_number") String invoice_number) {
		
		return this.invoice_service.getInvoice_MasterObjectByinvoice_number(invoice_number);

	}
	
	
	


	 
	 @GetMapping("/search/{keyword}")
	 public Map<String, List<?>> globalSearch(@PathVariable("keyword") String keyword) {
	     Map<String, List<?>> results = new HashMap<>();
	     //Document
	     //Invoice
	     Invoice_Master_Object invoice = invoice_service.getInvoice_MasterObjectsByKeyword(keyword);
	     List<Invoice_Master_Object> invoices = new ArrayList<>();
	     if (invoice != null) {
	         invoices.add(invoice);
	     }
	     
	     //SupplierContract
	     Supplier_MasterContractObject contract = supplier_contract_service.getSupplier_MasterContractObjectByKeyword(keyword);
	     List<Supplier_MasterContractObject> contracts = new ArrayList<>();
	     if (contract != null) {
	    	 contracts.add(contract);
	     }
	     
	     //Complaince_Certificate
	     Complaince_Certificate_MasterObject Certificate = compliance_certification_service.getComplaince_Certificate_MasterObjectByKeyword(keyword);
	     List<Complaince_Certificate_MasterObject> Certificates = new ArrayList<>();
	     if (Certificate != null) {
	    	 Certificates.add(Certificate);
	     }

	     //Certification_of_Insurance
	     Certification_of_Insurance_Master_Object Insurance = certification_of_insurance_service.getCertification_of_Insurance_Master_ObjectByKeyword(keyword);
	     List<Certification_of_Insurance_Master_Object> Insurances = new ArrayList<>();
	     if (Insurance != null) {
	    	 Insurances.add(Insurance);
	     }
	     
	     
	     
	     //Supplier
	     KKHSupplier_MasterObject Supplier = kkhSupplierService.getKKHSupplier_MasterObjectByKeyword(keyword);
	     List<KKHSupplier_MasterObject> Suppliers = new ArrayList<>();
	     if (Supplier != null) {
	    	 Suppliers.add(Supplier);
	     }
	     
	     
	     
	     //Parts
	     List<Supplier_MasterPartObject> products = supplier_MasterPartObjectDao.searchByPartNumberOrPartNameWithLatestParts(keyword);

	     
	     
	     
	     results.put("Invoice Document", invoices);
	     results.put("Parts", products);
	     results.put("Supplier_Contract Document", contracts);
	     results.put("Complaince_Certificate Document", Certificates);
	     results.put("Certification_of_Insurance Document", Insurances);  
	     results.put("Supplier", Suppliers); 
	     
	     if (invoices.isEmpty() && contracts.isEmpty() && Certificates.isEmpty() && Insurances.isEmpty() && Suppliers.isEmpty() && products.isEmpty()) {
	         results.put("Message", Collections.singletonList("No matches found for the keyword: " + keyword));
	     }
	     
	     return results;
	 }
	
}
