package com.kkh.KKHSupplierManagement.webservices;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.kkh.KKHSupplierManagement.resource.SupplierContractRequestBean;
import com.kkh.KKHSupplierManagement.resource.SupplierPartRequestBean;
import com.kkh.KKHSupplierManagement.resource.Supplier_Contract;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterContractObject;
import com.kkh.KKHSupplierManagement.resource.Supplier_MasterPartObject;
import com.kkh.KKHSupplierManagement.service.KKHSupplierService;
import com.kkh.KKHSupplierManagement.service.Supplier_Contract_Service;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class Supplier_ContractRestController {

	@Autowired
	private Supplier_Contract_Service supplier_contract_service;

	// add Supplier_Contract
	@PostMapping(path = "/addSupplier_Contract")
	public ResponseEntity<Void> addSupplier_Contract(@RequestBody Supplier_Contract supplier_contract) {

		Supplier_Contract supplier_contract1 = this.supplier_contract_service.addSupplier_Contract(supplier_contract);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{document_number}")
				.buildAndExpand(supplier_contract1.getDocument_number()).toUri();

		return ResponseEntity.created(uri).build();
	}

	// get Supplier_Contract
	@GetMapping("/getSupplier_Contract")
	public List<Supplier_Contract> getSupplier_contracts() {

		return this.supplier_contract_service.getSupplier_contracts();
	}

//	  	single Supplier_Contract get
	@GetMapping("/getIdSupplier_Contract/{document_number}")
	public @ResponseBody Supplier_Contract getSupplier_Contract(@PathVariable("document_number") Long document_number) {
		System.out.println("in get Supplier_Contract");

		return this.supplier_contract_service.getSupplier_Contract(document_number);

	}

//update course using PUT request
	@PutMapping("/updateSupplier_Contract")
	public Supplier_Contract updateSupplier_Contract(@RequestBody Supplier_Contract supplier_contract) {

		return this.supplier_contract_service.updateSupplier_Contract(supplier_contract);
	}

	// delete the course
	@DeleteMapping("/deleteSupplier_Contract/{document_number}")
	public ResponseEntity<HttpStatus> deleteSupplier_Contract(@PathVariable("document_number") String document_number) {

		HttpStatus status1 = this.supplier_contract_service.deleteSupplier_Contract(Long.parseLong(document_number));
		return new ResponseEntity<>(status1);

	}
	
	
	//History maintain code
	
		@PostMapping(path = "/CreateSupplierContract")
		public ResponseEntity<Void> createSupplier_Contract(@RequestBody SupplierContractRequestBean contractRequestBean) {

			
			SupplierContractRequestBean supplierContractRequestBean1 = this.supplier_contract_service.createSupplier_Contract(contractRequestBean);
			
			
			URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
					.buildAndExpand(supplierContractRequestBean1.getId()).toUri();

			return ResponseEntity.created(uri).build();
		}

		@GetMapping(path = "/getSupplierMasterContract")
		public ArrayList<SupplierContractRequestBean> getSupplierMasterContract() {

			
			ArrayList<SupplierContractRequestBean> supplierContractRequestBeanList = this.supplier_contract_service.getSupplierMasterContract();
			
			return supplierContractRequestBeanList;
		}
		
		//isletest id data show 
		@GetMapping(path = "/getSupplierMasterContractById/{masterId}")
		public Supplier_MasterContractObject getSupplierMasterContractObjectsById(@PathVariable("masterId") Long masterId) {
			
			Supplier_MasterContractObject supMasterContractObject = this.supplier_contract_service.getSupplierMasterContractObjectsById(masterId);
			return supMasterContractObject;
		}
		
		@PostMapping(path = "/SupplierMasterContractObject")
		public ResponseEntity<Void> createSupplier_ContractObject(@RequestBody Supplier_MasterContractObject masterContractObject) {

			
			Supplier_MasterContractObject supplier_MasterContractObject = this.supplier_contract_service.createSupplier_ContractObject(masterContractObject);
			
			
			URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
					.buildAndExpand(supplier_MasterContractObject.getId()).toUri();

		 	return ResponseEntity.created(uri).build();
		}
		
		
		@GetMapping(path = "/SupplierMasterContractObject")
		public List<Supplier_MasterContractObject> getSupplierMasterContractObjects() {
			
			List<Supplier_MasterContractObject> supMasterContractObjectList = this.supplier_contract_service.getSupplierMasterContractObjects();
			return supMasterContractObjectList;
		}
		


		@PutMapping(path = "/SupplierMasterContractObject")
		public ResponseEntity<Void> updateSupplier_ContractObject(@RequestBody Supplier_MasterContractObject masterContractObject) {

			
			Supplier_MasterContractObject supplier_MasterContractObject = this.supplier_contract_service.updateSupplier_ContractObject(masterContractObject);
			
			URI uri = ServletUriComponentsBuilder.fromCurrentRequest().fromPath("/{id}")
					.buildAndExpand(supplier_MasterContractObject.getId()).toUri();

			return ResponseEntity.created(uri).build();
		}
		
		
		@GetMapping(path = "/SupplierMasterContractObject/{masterId}")
		public Supplier_MasterContractObject getSupplierMasterContractObjectsHistoryById(@PathVariable("masterId") Long masterId) {
			
			Supplier_MasterContractObject supMasterContractObject = this.supplier_contract_service.getSupplierMasterContractObjectsHistoryById(masterId);
			return supMasterContractObject;
		}
		
		
		@DeleteMapping("/SupplierMasterContractObject/{masterId}")
		public ResponseEntity<HttpStatus> deleteSupplierMasterContractObject(@PathVariable("masterId") String masterId) {

			HttpStatus status = this.supplier_contract_service.deleteSupplierMasterContractObject(Long.parseLong(masterId));
			return new ResponseEntity<>(status);

		}

	
		
		@DeleteMapping("/SupplierContractObject/{id}")
		public ResponseEntity<HttpStatus> deleteSupplierContractObjectsHistoryById(@PathVariable("id") String id) {

			HttpStatus status = this.supplier_contract_service.deleteSupplierContractObjectsHistoryById(Long.parseLong(id));
			return new ResponseEntity<>(status);

		}
		
		@GetMapping(path = "/Supplier_MasterContractObjectBypart_number/{document_number}")
		public @ResponseBody List<Supplier_MasterContractObject> getSupplier_MasterContractObjectBydocument_number(@PathVariable("document_number") String document_number) {
			
		return this.supplier_contract_service.getSupplier_MasterContractObjectBydocument_number(document_number);

		}

}
