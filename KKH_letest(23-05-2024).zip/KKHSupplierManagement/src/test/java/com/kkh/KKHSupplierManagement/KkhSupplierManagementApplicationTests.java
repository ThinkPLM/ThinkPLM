package com.kkh.KKHSupplierManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KkhSupplierManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
